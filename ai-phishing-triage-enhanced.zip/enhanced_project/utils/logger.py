"""
Centralized logging configuration using loguru.
"""
import sys
from pathlib import Path
from loguru import logger as _logger


def setup_logger(log_level: str = "INFO", log_file: str = "data/app.log") -> None:
    """Configure loguru logger with console + file sinks."""
    Path(log_file).parent.mkdir(parents=True, exist_ok=True)

    _logger.remove()  # Remove default handler

    # Console handler — colorized
    _logger.add(
        sys.stderr,
        level=log_level,
        format=(
            "<green>{time:YYYY-MM-DD HH:mm:ss}</green> | "
            "<level>{level: <8}</level> | "
            "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> — "
            "<level>{message}</level>"
        ),
        colorize=True,
    )

    # File handler — JSON-structured for machine parsing
    _logger.add(
        log_file,
        level=log_level,
        rotation="10 MB",
        retention="7 days",
        compression="zip",
        format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {name}:{function}:{line} — {message}",
        serialize=False,
    )


# Apply default configuration immediately on import
setup_logger()

# Re-export the configured logger
logger = _logger
