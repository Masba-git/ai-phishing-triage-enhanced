"""
Configuration management for AI Phishing Triage System.
Loads settings from environment variables / .env file.
"""
from pathlib import Path
from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):
    """Application-wide settings loaded from environment / .env file."""

    # API
    api_host: str = Field(default="0.0.0.0", alias="API_HOST")
    api_port: int = Field(default=8000, alias="API_PORT")
    api_debug: bool = Field(default=False, alias="API_DEBUG")
    api_reload: bool = Field(default=False, alias="API_RELOAD")

    # Model paths
    model_path: str = Field(default="saved_models/phishing_model.joblib", alias="MODEL_PATH")
    vectorizer_path: str = Field(default="saved_models/tfidf_vectorizer.joblib", alias="VECTORIZER_PATH")
    scaler_path: str = Field(default="saved_models/feature_scaler.joblib", alias="SCALER_PATH")

    # Triage thresholds
    triage_db_path: str = Field(default="data/triage_history.json", alias="TRIAGE_DB_PATH")
    risk_threshold_safe: float = Field(default=0.2, alias="RISK_THRESHOLD_SAFE")
    risk_threshold_review: float = Field(default=0.4, alias="RISK_THRESHOLD_REVIEW")
    risk_threshold_suspicious: float = Field(default=0.6, alias="RISK_THRESHOLD_SUSPICIOUS")
    risk_threshold_quarantine: float = Field(default=0.8, alias="RISK_THRESHOLD_QUARANTINE")

    # Logging
    log_level: str = Field(default="INFO", alias="LOG_LEVEL")
    log_file: str = Field(default="data/app.log", alias="LOG_FILE")

    # Dashboard
    dashboard_port: int = Field(default=8501, alias="DASHBOARD_PORT")
    api_base_url: str = Field(default="http://localhost:8000", alias="API_BASE_URL")

    model_config = {"env_file": ".env", "populate_by_name": True}

    def ensure_dirs(self) -> None:
        """Create required directories if missing."""
        for path_str in [self.model_path, self.vectorizer_path, self.scaler_path,
                         self.triage_db_path, self.log_file]:
            Path(path_str).parent.mkdir(parents=True, exist_ok=True)


# Singleton settings instance
settings = Settings()
settings.ensure_dirs()
