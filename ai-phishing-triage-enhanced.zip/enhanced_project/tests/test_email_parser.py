"""
Tests for the email parser service.
"""
import sys
import pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

import pytest
from backend.services.email_parser import (
    parse_email, analyze_urls, analyze_attachments, analyze_sender,
    _extract_email_address, _extract_domain,
)

PHISHING_EMAIL = """\
From: "PayPal Security" <security@paypa1-secure.xyz>
Reply-To: harvest@evil.ru
Return-Path: <bounce@spam.info>
To: victim@company.com
Subject: URGENT: Verify your account
Date: Mon, 15 May 2024 08:00:00 +0000
Authentication-Results: spf=fail smtp.mailfrom=paypa1-secure.xyz;
  dkim=fail; dmarc=fail
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8

Click here now: http://192.168.1.1/login.php
Also: http://bit.ly/xyz123
Verify your password immediately or account suspended.
"""

LEGIT_EMAIL = """\
From: noreply@github.com
To: dev@company.com
Subject: SSH key added
Date: Tue, 16 May 2024 10:00:00 +0000
Authentication-Results: spf=pass; dkim=pass; dmarc=pass
Content-Type: text/plain

A new SSH key was added to your account.
Visit https://github.com/settings/keys to review.
"""


def test_parse_phishing_email():
    parsed = parse_email(PHISHING_EMAIL)
    assert parsed.from_address == "security@paypa1-secure.xyz"
    assert parsed.reply_to == "harvest@evil.ru"
    assert parsed.return_path == "bounce@spam.info"
    assert parsed.subject == "URGENT: Verify your account"
    assert parsed.spf_result == "fail"
    assert parsed.dkim_result == "fail"
    assert parsed.dmarc_result == "fail"
    assert len(parsed.urls) >= 2


def test_parse_legit_email():
    parsed = parse_email(LEGIT_EMAIL)
    assert parsed.from_address == "noreply@github.com"
    assert parsed.spf_result == "pass"
    assert parsed.dkim_result == "pass"
    assert "github.com" in (parsed.urls[0] if parsed.urls else "")


def test_parse_empty_email():
    parsed = parse_email("")
    assert parsed.from_address is None
    assert parsed.urls == []


def test_parse_malformed_email():
    parsed = parse_email("This is not a real email at all!!!")
    assert parsed is not None  # Should not raise


def test_url_analysis():
    urls = [
        "http://192.168.1.1/login",
        "https://bit.ly/abc123",
        "https://xn--pypal-4ve.com/login",
        "http://login.secure.paypal.verify.evil.xyz/account",
    ]
    result = analyze_urls(urls, {})
    assert len(result["ip_based_urls"]) == 1
    assert len(result["shortener_urls"]) == 1
    assert len(result["punycode_domains"]) == 1
    assert result["total_urls"] == 4


def test_attachment_analysis():
    attachments = [
        {"filename": "invoice.docm", "mime_type": "application/vnd.ms-word.document.macroEnabled.12", "size_bytes": 50000},
        {"filename": "readme.txt", "mime_type": "text/plain", "size_bytes": 200},
        {"filename": "payload.exe", "mime_type": "application/octet-stream", "size_bytes": 102400},
    ]
    result = analyze_attachments(attachments)
    assert result["macro_enabled_count"] == 1
    assert result["executable_count"] == 1
    assert result["has_dangerous_attachment"] is True


def test_sender_analysis_typosquatting():
    result = analyze_sender("security@paypa1.com")
    assert result["typosquatting_score"] > 0.5
    assert "paypal.com" in result["domain_similarity_targets"]


def test_sender_analysis_free_provider():
    result = analyze_sender("user@gmail.com")
    assert result["free_email_provider"] is True


def test_extract_email_address():
    assert _extract_email_address('"PayPal" <security@paypal.com>') == "security@paypal.com"
    assert _extract_email_address("user@example.com") == "user@example.com"
    assert _extract_email_address(None) is None


def test_extract_domain():
    assert _extract_domain("user@example.com") == "example.com"
    assert _extract_domain(None) is None
    assert _extract_domain("notanemail") is None
