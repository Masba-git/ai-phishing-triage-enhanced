"""
Tests for feature extraction and explainability engine.
"""
import sys
import pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

import pytest
from backend.services.email_parser import parse_email
from backend.services.feature_extractor import (
    extract_all_features, build_numeric_feature_vector, extract_body_features,
)
from backend.services.explainability import (
    generate_indicators, compute_rule_based_score,
)

PHISHING_EMAIL = """\
From: "PayPal Security" <security@paypa1-secure.xyz>
Reply-To: harvest@evil.ru
Return-Path: <bounce@spam.info>
To: victim@company.com
Subject: URGENT: Verify your account NOW
Date: Mon, 15 May 2024 08:00:00 +0000
Authentication-Results: spf=fail; dkim=fail; dmarc=fail
Content-Type: text/plain; charset=UTF-8

URGENT: Your account will be suspended in 24 hours!
Click here to verify your password: http://192.168.1.1/login.php
Also check: http://bit.ly/xyz123
Please confirm your login credentials immediately.
"""


def test_extract_all_features_keys():
    parsed = parse_email(PHISHING_EMAIL)
    features = extract_all_features(parsed)
    assert "headers" in features
    assert "body" in features
    assert "urls" in features
    assert "attachments" in features
    assert "sender" in features


def test_header_features_mismatch():
    parsed = parse_email(PHISHING_EMAIL)
    features = extract_all_features(parsed)
    h = features["headers"]
    assert h["from_reply_to_mismatch"] is True
    assert h["return_path_mismatch"] is True


def test_body_features_urgency():
    parsed = parse_email(PHISHING_EMAIL)
    features = extract_all_features(parsed)
    b = features["body"]
    assert b["urgency_score"] > 0.0
    assert b["credential_bait_score"] > 0.0
    assert len(b["suspicious_keywords"]) > 0


def test_numeric_feature_vector_shape():
    parsed = parse_email(PHISHING_EMAIL)
    features = extract_all_features(parsed)
    vec = build_numeric_feature_vector(features)
    assert len(vec) == 32
    for val in vec.values():
        assert 0.0 <= val <= 1.0, f"Feature out of range: {val}"


def test_rule_based_score_phishing():
    parsed = parse_email(PHISHING_EMAIL)
    features = extract_all_features(parsed)
    score = compute_rule_based_score(features)
    assert score > 0.3, f"Expected high rule score for phishing, got {score}"
    assert 0.0 <= score <= 1.0


def test_generate_indicators_returns_list():
    parsed = parse_email(PHISHING_EMAIL)
    features = extract_all_features(parsed)
    indicators = generate_indicators(features)
    assert isinstance(indicators, list)
    assert len(indicators) > 0
    assert all(isinstance(i, str) for i in indicators)


def test_generate_indicators_not_empty_for_phishing():
    parsed = parse_email(PHISHING_EMAIL)
    features = extract_all_features(parsed)
    indicators = generate_indicators(features)
    assert "No significant" not in indicators[0], "Should detect phishing indicators"


def test_clean_email_low_score():
    clean = """\
From: noreply@github.com
To: dev@company.com
Subject: New SSH key added
Authentication-Results: spf=pass; dkim=pass; dmarc=pass
Content-Type: text/plain

A new SSH key was added. Visit https://github.com/settings/keys to review.
"""
    parsed = parse_email(clean)
    features = extract_all_features(parsed)
    score = compute_rule_based_score(features)
    assert score < 0.4, f"Expected low rule score for clean email, got {score}"
