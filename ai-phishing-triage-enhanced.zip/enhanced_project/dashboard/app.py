"""
AI Phishing Email Triage System — Streamlit Dashboard

A production-style SOC analyst dashboard for phishing email analysis.

Run with:
    streamlit run dashboard/app.py
"""
from __future__ import annotations

import io
import json
import os
import time
from typing import Any, Dict, List, Optional

import plotly.express as px
import plotly.graph_objects as go
import requests
import streamlit as st

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
API_BASE = os.getenv("API_BASE_URL", "http://localhost:8000")
API_V1 = f"{API_BASE}/api/v1"
REQUEST_TIMEOUT = 30

# ---------------------------------------------------------------------------
# Page config — must be first Streamlit call
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="PhishTriage AI",
    page_icon="🎣",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------------------------------------------------------------------------
# Custom CSS — SOC terminal aesthetic
# ---------------------------------------------------------------------------
st.markdown(
    """
    <style>
    /* ── Base ── */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

    html, body, [class*="css"] {
        font-family: 'Inter', sans-serif;
    }

    /* ── Background ── */
    .stApp {
        background: linear-gradient(135deg, #0a0e1a 0%, #0d1428 50%, #0a1020 100%);
        color: #e2e8f0;
    }

    /* ── Sidebar ── */
    [data-testid="stSidebar"] {
        background: linear-gradient(180deg, #0d1428 0%, #0a1020 100%);
        border-right: 1px solid #1e3a5f;
    }
    [data-testid="stSidebar"] .stRadio > label {
        color: #94a3b8 !important;
        font-weight: 500;
    }

    /* ── Metric cards ── */
    [data-testid="stMetric"] {
        background: rgba(30, 58, 95, 0.3);
        border: 1px solid #1e3a5f;
        border-radius: 12px;
        padding: 16px;
        backdrop-filter: blur(10px);
    }
    [data-testid="stMetricLabel"] { color: #94a3b8 !important; font-size: 0.8rem !important; text-transform: uppercase; letter-spacing: 0.05em; }
    [data-testid="stMetricValue"] { color: #38bdf8 !important; font-family: 'JetBrains Mono', monospace !important; font-size: 1.8rem !important; }

    /* ── Cards / expanders ── */
    [data-testid="stExpander"] {
        background: rgba(15, 23, 42, 0.7);
        border: 1px solid #1e3a5f;
        border-radius: 12px;
    }

    /* ── Buttons ── */
    .stButton > button {
        background: linear-gradient(135deg, #1d4ed8, #2563eb);
        color: white;
        border: none;
        border-radius: 8px;
        padding: 10px 24px;
        font-weight: 600;
        letter-spacing: 0.02em;
        transition: all 0.2s;
        width: 100%;
    }
    .stButton > button:hover {
        background: linear-gradient(135deg, #2563eb, #3b82f6);
        box-shadow: 0 0 20px rgba(59, 130, 246, 0.4);
        transform: translateY(-1px);
    }

    /* ── Text area / inputs ── */
    .stTextArea > div > textarea {
        background: rgba(15, 23, 42, 0.8);
        border: 1px solid #1e3a5f;
        border-radius: 8px;
        color: #e2e8f0;
        font-family: 'JetBrains Mono', monospace;
        font-size: 0.8rem;
    }

    /* ── File uploader ── */
    [data-testid="stFileUploader"] {
        background: rgba(15, 23, 42, 0.5);
        border: 2px dashed #1e3a5f;
        border-radius: 12px;
        padding: 20px;
    }

    /* ── Headers ── */
    h1, h2, h3 { color: #e2e8f0 !important; }

    /* ── Tables ── */
    .stDataFrame { border-radius: 8px; overflow: hidden; }

    /* ── Verdict badge ── */
    .verdict-badge {
        display: inline-block;
        padding: 6px 18px;
        border-radius: 20px;
        font-weight: 700;
        font-size: 1rem;
        letter-spacing: 0.05em;
        text-transform: uppercase;
    }
    .verdict-safe       { background: rgba(16,185,129,0.2); color: #10b981; border: 1px solid #10b981; }
    .verdict-review     { background: rgba(59,130,246,0.2); color: #60a5fa; border: 1px solid #60a5fa; }
    .verdict-suspicious { background: rgba(251,191,36,0.2); color: #fbbf24; border: 1px solid #fbbf24; }
    .verdict-quarantine { background: rgba(249,115,22,0.2); color: #f97316; border: 1px solid #f97316; }
    .verdict-phishing   { background: rgba(239,68,68,0.2);  color: #ef4444; border: 1px solid #ef4444; }

    /* ── Indicator items ── */
    .indicator-item {
        background: rgba(239,68,68,0.08);
        border-left: 3px solid #ef4444;
        padding: 8px 14px;
        margin: 4px 0;
        border-radius: 0 6px 6px 0;
        font-size: 0.88rem;
        color: #fca5a5;
    }
    .indicator-safe {
        background: rgba(16,185,129,0.08);
        border-left: 3px solid #10b981;
        color: #6ee7b7;
    }

    /* ── Score gauge container ── */
    .score-container {
        text-align: center;
        padding: 10px;
    }

    /* ── Divider ── */
    hr { border-color: #1e3a5f; }

    /* ── Code blocks ── */
    code { font-family: 'JetBrains Mono', monospace !important; font-size: 0.8rem; }

    /* ── Info / warning boxes ── */
    .stAlert { border-radius: 8px; }

    /* ── Tab labels ── */
    .stTabs [data-baseweb="tab"] { color: #94a3b8; font-weight: 500; }
    .stTabs [aria-selected="true"] { color: #38bdf8 !important; border-bottom-color: #38bdf8 !important; }

    /* ── Scrollbar ── */
    ::-webkit-scrollbar { width: 6px; height: 6px; }
    ::-webkit-scrollbar-track { background: #0a0e1a; }
    ::-webkit-scrollbar-thumb { background: #1e3a5f; border-radius: 3px; }
    </style>
    """,
    unsafe_allow_html=True,
)


# ---------------------------------------------------------------------------
# API helpers
# ---------------------------------------------------------------------------

def api_health() -> Dict[str, Any]:
    try:
        r = requests.get(f"{API_V1}/health", timeout=5)
        r.raise_for_status()
        return r.json()
    except Exception:
        return {"status": "unreachable", "model_loaded": False}


def api_analyze(raw_email: str, filename: Optional[str] = None) -> Optional[Dict[str, Any]]:
    try:
        payload = {"raw_email": raw_email, "filename": filename}
        r = requests.post(f"{API_V1}/analyze", json=payload, timeout=REQUEST_TIMEOUT)
        r.raise_for_status()
        return r.json()
    except requests.exceptions.ConnectionError:
        st.error("❌ Cannot connect to API. Is the backend running? `uvicorn backend.main:app --port 8000`")
        return None
    except Exception as exc:
        st.error(f"API error: {exc}")
        return None


def api_analyze_file(file_bytes: bytes, filename: str) -> Optional[Dict[str, Any]]:
    try:
        files = {"file": (filename, io.BytesIO(file_bytes), "message/rfc822")}
        r = requests.post(f"{API_V1}/analyze-file", files=files, timeout=REQUEST_TIMEOUT)
        r.raise_for_status()
        return r.json()
    except requests.exceptions.ConnectionError:
        st.error("❌ Cannot connect to API. Is the backend running?")
        return None
    except Exception as exc:
        st.error(f"File upload error: {exc}")
        return None


def api_triage_history(limit: int = 200) -> List[Dict[str, Any]]:
    try:
        r = requests.get(f"{API_V1}/triage-history", params={"limit": limit}, timeout=10)
        r.raise_for_status()
        return r.json().get("records", [])
    except Exception:
        return []


def api_triage_stats() -> Dict[str, Any]:
    try:
        r = requests.get(f"{API_V1}/triage-stats", timeout=10)
        r.raise_for_status()
        return r.json()
    except Exception:
        return {}


def api_model_info() -> Dict[str, Any]:
    try:
        r = requests.get(f"{API_V1}/model-info", timeout=10)
        r.raise_for_status()
        return r.json()
    except Exception:
        return {}


def api_triage_update(analysis_id: str, override: str, note: str) -> bool:
    try:
        payload = {"analysis_id": analysis_id, "analyst_override": override, "analyst_note": note}
        r = requests.post(f"{API_V1}/triage-update", json=payload, timeout=10)
        r.raise_for_status()
        return True
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Verdict helpers
# ---------------------------------------------------------------------------

VERDICT_CSS = {
    "Safe": "verdict-safe",
    "Review": "verdict-review",
    "Suspicious": "verdict-suspicious",
    "Quarantine": "verdict-quarantine",
    "Confirmed Phishing": "verdict-phishing",
}

VERDICT_EMOJI = {
    "Safe": "✅",
    "Review": "🔵",
    "Suspicious": "⚠️",
    "Quarantine": "🔶",
    "Confirmed Phishing": "🚨",
}

VERDICT_COLOR = {
    "Safe": "#10b981",
    "Review": "#60a5fa",
    "Suspicious": "#fbbf24",
    "Quarantine": "#f97316",
    "Confirmed Phishing": "#ef4444",
}


def verdict_badge(verdict: str) -> str:
    css = VERDICT_CSS.get(verdict, "verdict-review")
    emoji = VERDICT_EMOJI.get(verdict, "❓")
    return f'<span class="verdict-badge {css}">{emoji} {verdict}</span>'


# ---------------------------------------------------------------------------
# Gauge chart
# ---------------------------------------------------------------------------

def risk_gauge(score: float, verdict: str) -> go.Figure:
    color = VERDICT_COLOR.get(verdict, "#60a5fa")
    pct = int(score * 100)

    fig = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=pct,
        number={
            "suffix": "%",
            "font": {"size": 40, "color": color, "family": "JetBrains Mono"},
        },
        delta={"reference": 50, "valueformat": ".0f"},
        gauge={
            "axis": {
                "range": [0, 100],
                "tickwidth": 1,
                "tickcolor": "#1e3a5f",
                "tickfont": {"color": "#64748b", "size": 10},
            },
            "bar": {"color": color, "thickness": 0.3},
            "bgcolor": "rgba(0,0,0,0)",
            "borderwidth": 0,
            "steps": [
                {"range": [0, 20],  "color": "rgba(16,185,129,0.15)"},
                {"range": [20, 40], "color": "rgba(59,130,246,0.15)"},
                {"range": [40, 60], "color": "rgba(251,191,36,0.15)"},
                {"range": [60, 80], "color": "rgba(249,115,22,0.15)"},
                {"range": [80, 100], "color": "rgba(239,68,68,0.15)"},
            ],
            "threshold": {
                "line": {"color": color, "width": 3},
                "thickness": 0.8,
                "value": pct,
            },
        },
        title={"text": "RISK SCORE", "font": {"size": 13, "color": "#64748b"}},
    ))

    fig.update_layout(
        height=260,
        margin=dict(l=20, r=20, t=40, b=10),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font={"color": "#e2e8f0"},
    )
    return fig


# ---------------------------------------------------------------------------
# Feature importance bar chart
# ---------------------------------------------------------------------------

def feature_importance_chart(importance: Dict[str, float]) -> Optional[go.Figure]:
    if not importance:
        return None
    items = sorted(importance.items(), key=lambda x: x[1], reverse=True)[:12]
    labels = [i[0].replace("_", " ").title() for i in items]
    values = [i[1] for i in items]

    fig = go.Figure(go.Bar(
        x=values,
        y=labels,
        orientation="h",
        marker=dict(
            color=values,
            colorscale=[[0, "#1e3a5f"], [0.5, "#2563eb"], [1, "#ef4444"]],
            showscale=False,
        ),
        text=[f"{v:.4f}" for v in values],
        textposition="outside",
        textfont={"color": "#94a3b8", "size": 10},
    ))
    fig.update_layout(
        height=350,
        margin=dict(l=10, r=80, t=10, b=10),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        xaxis={"showgrid": False, "zeroline": False, "tickfont": {"color": "#64748b"}},
        yaxis={"showgrid": False, "tickfont": {"color": "#94a3b8"}, "autorange": "reversed"},
        bargap=0.3,
    )
    return fig


# ---------------------------------------------------------------------------
# Body score radar chart
# ---------------------------------------------------------------------------

def body_radar(body: Dict[str, Any]) -> go.Figure:
    categories = ["Urgency", "Credential Bait", "Financial Bait", "Social Engineering"]
    values = [
        body.get("urgency_score", 0),
        body.get("credential_bait_score", 0),
        body.get("financial_bait_score", 0),
        body.get("social_engineering_score", 0),
    ]

    fig = go.Figure(go.Scatterpolar(
        r=values + [values[0]],
        theta=categories + [categories[0]],
        fill="toself",
        fillcolor="rgba(239,68,68,0.15)",
        line={"color": "#ef4444", "width": 2},
        marker={"color": "#ef4444", "size": 6},
    ))
    fig.update_layout(
        polar=dict(
            bgcolor="rgba(0,0,0,0)",
            radialaxis=dict(
                visible=True, range=[0, 1],
                tickfont={"color": "#64748b", "size": 9},
                gridcolor="#1e3a5f",
            ),
            angularaxis=dict(
                tickfont={"color": "#94a3b8", "size": 11},
                gridcolor="#1e3a5f",
                linecolor="#1e3a5f",
            ),
        ),
        paper_bgcolor="rgba(0,0,0,0)",
        height=280,
        margin=dict(l=30, r=30, t=30, b=30),
        showlegend=False,
    )
    return fig


# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------

def sidebar() -> str:
    with st.sidebar:
        st.markdown(
            """
            <div style="text-align:center; padding: 20px 0 10px 0;">
                <div style="font-size:2.5rem;">🎣</div>
                <div style="font-size:1.2rem; font-weight:700; color:#38bdf8; letter-spacing:0.05em;">PhishTriage AI</div>
                <div style="font-size:0.7rem; color:#64748b; margin-top:4px;">SOC Analyst Platform</div>
            </div>
            <hr style="border-color:#1e3a5f; margin: 10px 0 20px 0;">
            """,
            unsafe_allow_html=True,
        )

        page = st.radio(
            "Navigation",
            [
                "🔍 Analyze Email",
                "📊 Analysis Result",
                "📋 Triage History",
                "📈 Statistics",
                "🤖 Model Info",
            ],
            label_visibility="collapsed",
        )

        # API health indicator
        st.markdown("<hr style='border-color:#1e3a5f; margin: 20px 0 10px 0;'>", unsafe_allow_html=True)
        health = api_health()
        status = health.get("status", "unreachable")
        model_ok = health.get("model_loaded", False)

        status_color = "#10b981" if status == "ok" else "#ef4444"
        model_color = "#10b981" if model_ok else "#fbbf24"

        st.markdown(
            f"""
            <div style="font-size:0.75rem; color:#64748b; text-transform:uppercase; letter-spacing:0.05em; margin-bottom:8px;">System Status</div>
            <div style="display:flex; align-items:center; gap:8px; margin-bottom:6px;">
                <div style="width:8px;height:8px;border-radius:50%;background:{status_color};box-shadow:0 0 6px {status_color};"></div>
                <span style="color:#94a3b8;font-size:0.82rem;">API: <span style="color:{status_color};">{status.upper()}</span></span>
            </div>
            <div style="display:flex; align-items:center; gap:8px;">
                <div style="width:8px;height:8px;border-radius:50%;background:{model_color};box-shadow:0 0 6px {model_color};"></div>
                <span style="color:#94a3b8;font-size:0.82rem;">Model: <span style="color:{model_color};">{"LOADED" if model_ok else "FALLBACK"}</span></span>
            </div>
            """,
            unsafe_allow_html=True,
        )

        st.markdown(
            """
            <div style="position:fixed; bottom:20px; left:0; width:280px; text-align:center;">
                <div style="font-size:0.65rem; color:#334155;">AI Phishing Triage System v1.0</div>
                <div style="font-size:0.65rem; color:#334155;">Defensive Use Only</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    return page


# ---------------------------------------------------------------------------
# Page: Analyze Email
# ---------------------------------------------------------------------------

def page_analyze() -> None:
    st.markdown(
        """
        <h1 style="margin-bottom:4px;">🔍 Email Analysis</h1>
        <p style="color:#64748b; margin-bottom:24px;">Upload an .eml file or paste raw email text for phishing analysis</p>
        """,
        unsafe_allow_html=True,
    )

    tab1, tab2 = st.tabs(["📁 Upload .eml File", "📝 Paste Raw Email"])

    with tab1:
        st.markdown("#### Upload Email File")
        uploaded = st.file_uploader(
            "Drop your .eml file here",
            type=["eml", "txt", "msg"],
            help="RFC-5322 formatted email files",
            label_visibility="collapsed",
        )

        if uploaded:
            col1, col2 = st.columns([2, 1])
            with col1:
                st.info(f"📎 **{uploaded.name}** ({uploaded.size:,} bytes)")
            with col2:
                if st.button("🚀 Analyze File", key="analyze_file_btn"):
                    with st.spinner("🔍 Analyzing email..."):
                        result = api_analyze_file(uploaded.read(), uploaded.name)
                    if result:
                        st.session_state["last_result"] = result
                        st.session_state["active_page"] = "📊 Analysis Result"
                        st.success("✅ Analysis complete! Navigate to **Analysis Result**")
                        st.rerun()

    with tab2:
        st.markdown("#### Paste Raw Email Text")

        # Sample email buttons
        col1, col2, col3 = st.columns(3)
        with col1:
            if st.button("🎯 Load Phishing Sample", key="load_phish"):
                st.session_state["pasted_email"] = PHISHING_SAMPLE
        with col2:
            if st.button("✅ Load Legit Sample", key="load_legit"):
                st.session_state["pasted_email"] = LEGIT_SAMPLE
        with col3:
            if st.button("🗑️ Clear", key="clear_email"):
                st.session_state["pasted_email"] = ""

        email_text = st.text_area(
            "Raw Email",
            value=st.session_state.get("pasted_email", ""),
            height=320,
            placeholder="Paste RFC-5322 email content here...\n\nFrom: sender@example.com\nTo: victim@target.com\nSubject: Urgent: Verify your account\n...",
            label_visibility="collapsed",
        )

        if email_text:
            st.markdown(
                f"<div style='color:#64748b;font-size:0.8rem;'>Characters: {len(email_text):,} | Lines: {email_text.count(chr(10)):,}</div>",
                unsafe_allow_html=True,
            )

        if st.button("🚀 Analyze Email", key="analyze_paste_btn", disabled=not bool(email_text.strip())):
            with st.spinner("🔍 Running phishing analysis pipeline..."):
                result = api_analyze(email_text, filename="pasted_email.eml")
            if result:
                st.session_state["last_result"] = result
                st.session_state["active_page"] = "📊 Analysis Result"
                st.success("✅ Analysis complete! Navigate to **Analysis Result**")
                st.rerun()


# ---------------------------------------------------------------------------
# Page: Analysis Result
# ---------------------------------------------------------------------------

def page_result() -> None:
    result = st.session_state.get("last_result")

    if not result:
        st.markdown(
            """
            <div style="text-align:center; padding: 80px 20px;">
                <div style="font-size:4rem; margin-bottom:16px;">📭</div>
                <h2 style="color:#94a3b8;">No Analysis Yet</h2>
                <p style="color:#64748b;">Go to <strong>Analyze Email</strong> and submit an email first.</p>
            </div>
            """,
            unsafe_allow_html=True,
        )
        return

    verdict = result.get("verdict", "Unknown")
    risk_score = result.get("risk_score", 0.0)
    risk_pct = result.get("risk_percent", 0)
    confidence = result.get("confidence", 0.0)
    analysis_id = result.get("analysis_id", "")
    triage_status = result.get("triage_status", "unknown")

    # ── Header row ──────────────────────────────────────────────────────────
    col_title, col_id = st.columns([3, 1])
    with col_title:
        st.markdown(f"<h1 style='margin-bottom:2px;'>📊 Analysis Result</h1>", unsafe_allow_html=True)
        st.markdown(
            f"<p style='color:#64748b; font-family: JetBrains Mono, monospace; font-size:0.8rem;'>ID: {analysis_id}</p>",
            unsafe_allow_html=True,
        )
    with col_id:
        st.markdown(
            f"<div style='text-align:right; padding-top:10px;'>{verdict_badge(verdict)}</div>",
            unsafe_allow_html=True,
        )

    st.markdown("<hr>", unsafe_allow_html=True)

    # ── Top metrics row ──────────────────────────────────────────────────────
    m1, m2, m3, m4, m5 = st.columns(5)
    with m1:
        st.metric("Risk Score", f"{risk_pct}%", delta=None)
    with m2:
        st.metric("Confidence", f"{confidence*100:.1f}%")
    with m3:
        urls_total = result.get("urls", {}).get("total_urls", 0)
        st.metric("URLs Found", urls_total)
    with m4:
        has_att = result.get("attachments", {}).get("has_dangerous_attachment", False)
        st.metric("Dangerous Attachment", "YES ⚠️" if has_att else "No")
    with m5:
        kw_count = len(result.get("body", {}).get("suspicious_keywords", []))
        st.metric("Phishing Keywords", kw_count)

    st.markdown("<br>", unsafe_allow_html=True)

    # ── Gauge + Indicators ───────────────────────────────────────────────────
    gcol, icol = st.columns([1, 2])

    with gcol:
        st.plotly_chart(risk_gauge(risk_score, verdict), use_container_width=True)
        st.markdown(
            f"""
            <div style="text-align:center; margin-top:-10px;">
                <div style="font-size:0.75rem; color:#64748b; text-transform:uppercase; letter-spacing:0.08em;">Triage Status</div>
                <div style="font-size:1rem; font-weight:600; color:#38bdf8; margin-top:4px;">{triage_status.upper()}</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with icol:
        st.markdown(
            "<div style='font-size:0.75rem; color:#64748b; text-transform:uppercase; letter-spacing:0.08em; margin-bottom:10px;'>🔴 Top Phishing Indicators</div>",
            unsafe_allow_html=True,
        )
        indicators = result.get("top_indicators", [])
        if indicators:
            for indicator in indicators:
                is_safe = "No significant" in indicator
                css = "indicator-safe" if is_safe else "indicator-item"
                icon = "✓" if is_safe else "⚠"
                st.markdown(
                    f'<div class="{css}">{icon} {indicator}</div>',
                    unsafe_allow_html=True,
                )
        else:
            st.markdown('<div class="indicator-safe">✓ No significant phishing indicators detected</div>', unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # ── Detail tabs ──────────────────────────────────────────────────────────
    t1, t2, t3, t4, t5, t6, t7 = st.tabs([
        "📧 Headers", "📝 Body", "🔗 URLs", "📎 Attachments", "👤 Sender", "🤖 ML Insights", "🎯 Attack Types"
    ])

    with t1:
        _render_headers(result.get("headers", {}))

    with t2:
        _render_body(result.get("body", {}))

    with t3:
        _render_urls(result.get("urls", {}))

    with t4:
        _render_attachments(result.get("attachments", {}))

    with t5:
        _render_sender(result.get("sender", {}))

    with t6:
        _render_ml_insights(result)

    with t7:
        _render_attack_types(result)

    # ── Analyst override ─────────────────────────────────────────────────────
    st.markdown("<br><hr>", unsafe_allow_html=True)
    st.markdown("### 🔧 Analyst Override")

    ocol1, ocol2 = st.columns([2, 1])
    with ocol1:
        override_choice = st.selectbox(
            "Override Triage Status",
            ["safe", "review", "suspicious", "quarantine", "confirmed_phishing"],
            key="override_select",
        )
        override_note = st.text_input("Analyst Note", placeholder="e.g., Confirmed spear-phishing targeting finance dept", key="override_note")
    with ocol2:
        st.markdown("<br><br>", unsafe_allow_html=True)
        if st.button("💾 Apply Override", key="override_btn"):
            if analysis_id:
                success = api_triage_update(analysis_id, override_choice, override_note)
                if success:
                    st.success(f"✅ Override applied: **{override_choice}**")
                else:
                    st.error("Failed to apply override — check API connection")


def _bool_indicator(value: bool, true_label: str = "YES", false_label: str = "No") -> str:
    if value:
        return f"<span style='color:#ef4444; font-weight:600;'>⚠ {true_label}</span>"
    return f"<span style='color:#10b981;'>✓ {false_label}</span>"


def _auth_badge(result: Optional[str]) -> str:
    if result is None:
        return "<span style='color:#64748b;'>–</span>"
    r = result.lower()
    if r == "pass":
        return f"<span style='color:#10b981; font-weight:600;'>✓ PASS</span>"
    elif r in ("fail", "softfail"):
        return f"<span style='color:#ef4444; font-weight:600;'>✗ {r.upper()}</span>"
    return f"<span style='color:#fbbf24;'>{r.upper()}</span>"


def _render_headers(h: Dict[str, Any]) -> None:
    col1, col2 = st.columns(2)

    with col1:
        st.markdown("**Email Metadata**")
        fields = [
            ("From", h.get("from_address", "–")),
            ("Reply-To", h.get("reply_to") or "–"),
            ("Return-Path", h.get("return_path") or "–"),
            ("Subject", h.get("subject") or "–"),
            ("Date", h.get("date") or "–"),
            ("Mailer", h.get("mailer") or "–"),
            ("Message-ID", (h.get("message_id") or "–")[:50]),
        ]
        for label, value in fields:
            st.markdown(
                f"<div style='display:flex; gap:12px; padding:6px 0; border-bottom:1px solid #1e3a5f;'>"
                f"<span style='color:#64748b; font-size:0.8rem; min-width:100px;'>{label}</span>"
                f"<span style='color:#e2e8f0; font-size:0.8rem; font-family:JetBrains Mono,monospace; word-break:break-all;'>{value}</span>"
                f"</div>",
                unsafe_allow_html=True,
            )

    with col2:
        st.markdown("**Authentication Results**")
        auth_rows = [
            ("SPF", h.get("spf_result")),
            ("DKIM", h.get("dkim_result")),
            ("DMARC", h.get("dmarc_result")),
        ]
        for label, val in auth_rows:
            st.markdown(
                f"<div style='display:flex; gap:12px; padding:8px 0; border-bottom:1px solid #1e3a5f;'>"
                f"<span style='color:#64748b; font-size:0.85rem; min-width:80px; font-weight:600;'>{label}</span>"
                f"{_auth_badge(val)}"
                f"</div>",
                unsafe_allow_html=True,
            )

        st.markdown("<br>**Spoofing Signals**")
        spoof_rows = [
            ("From/Reply-To Mismatch", h.get("from_reply_to_mismatch", False)),
            ("Return-Path Mismatch", h.get("return_path_mismatch", False)),
            ("Display Name Spoofing", h.get("display_name_spoofing", False)),
            ("Suspicious Relay Chain", h.get("suspicious_relay", False)),
        ]
        for label, val in spoof_rows:
            st.markdown(
                f"<div style='display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px solid #1e3a5f;'>"
                f"<span style='color:#94a3b8; font-size:0.82rem;'>{label}</span>"
                f"{_bool_indicator(val)}"
                f"</div>",
                unsafe_allow_html=True,
            )


def _render_body(b: Dict[str, Any]) -> None:
    col1, col2 = st.columns([1, 1])

    with col1:
        st.markdown("**Body Language Scores**")
        radar_fig = body_radar(b)
        st.plotly_chart(radar_fig, use_container_width=True)

    with col2:
        st.markdown("**Detected Phishing Keywords**")
        keywords = b.get("suspicious_keywords", [])
        if keywords:
            kw_html = " ".join(
                f"<span style='background:rgba(239,68,68,0.15); color:#fca5a5; border:1px solid rgba(239,68,68,0.3); "
                f"padding:3px 10px; border-radius:12px; font-size:0.78rem; margin:3px; display:inline-block;'>{kw}</span>"
                for kw in keywords
            )
            st.markdown(kw_html, unsafe_allow_html=True)
        else:
            st.markdown("<span style='color:#10b981;'>✓ No suspicious keywords detected</span>", unsafe_allow_html=True)

        st.markdown("<br>**Statistics**")
        stats = [
            ("Word Count", b.get("word_count", 0)),
            ("Character Count", b.get("char_count", 0)),
            ("HTML Body", "Yes" if b.get("html_present") else "No"),
        ]
        for label, val in stats:
            st.markdown(
                f"<div style='display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px solid #1e3a5f;'>"
                f"<span style='color:#94a3b8; font-size:0.82rem;'>{label}</span>"
                f"<span style='color:#e2e8f0; font-weight:600;'>{val}</span>"
                f"</div>",
                unsafe_allow_html=True,
            )

    if b.get("plain_text"):
        with st.expander("📄 View Email Body Text", expanded=False):
            st.text(b["plain_text"][:3000] + ("..." if len(b["plain_text"]) > 3000 else ""))


def _render_urls(u: Dict[str, Any]) -> None:
    total = u.get("total_urls", 0)
    phish_count = u.get("phishing_url_count", 0)

    m1, m2, m3, m4 = st.columns(4)
    with m1: st.metric("Total URLs", total)
    with m2: st.metric("Phishing URLs", phish_count)
    with m3: st.metric("Shorteners", len(u.get("shortener_urls", [])))
    with m4: st.metric("IP-Based", len(u.get("ip_based_urls", [])))

    url_categories = {
        "IP-Based URLs": (u.get("ip_based_urls", []), "#ef4444"),
        "URL Shorteners": (u.get("shortener_urls", []), "#f97316"),
        "Brand Impersonation": (u.get("brand_impersonation_urls", []), "#ef4444"),
        "Punycode/IDN": (u.get("punycode_domains", []), "#f97316"),
        "Anchor Mismatch": (u.get("anchor_mismatch_urls", []), "#fbbf24"),
        "Suspicious TLDs": (u.get("suspicious_tlds", []), "#fbbf24"),
        "HTTP Only": (u.get("http_only_urls", []), "#60a5fa"),
        "Excessive Subdomains": (u.get("excessive_subdomain_urls", []), "#a78bfa"),
    }

    for category, (urls, color) in url_categories.items():
        if urls:
            with st.expander(f"⚠ {category} ({len(urls)})", expanded=False):
                for url in urls[:10]:
                    st.markdown(
                        f"<div style='font-family:JetBrains Mono,monospace; font-size:0.75rem; "
                        f"color:{color}; padding:4px 8px; background:rgba(0,0,0,0.3); "
                        f"border-radius:4px; margin:3px 0; word-break:break-all;'>{url}</div>",
                        unsafe_allow_html=True,
                    )

    if not any(urls for urls, _ in url_categories.values()):
        st.markdown("<span style='color:#10b981;'>✓ No suspicious URLs detected</span>", unsafe_allow_html=True)

    all_urls = u.get("urls_found", [])
    if all_urls:
        with st.expander(f"📋 All URLs ({len(all_urls)})", expanded=False):
            for url in all_urls[:50]:
                st.markdown(
                    f"<div style='font-family:JetBrains Mono,monospace; font-size:0.72rem; "
                    f"color:#94a3b8; padding:3px 0; word-break:break-all;'>{url}</div>",
                    unsafe_allow_html=True,
                )


def _render_attachments(a: Dict[str, Any]) -> None:
    attachments = a.get("attachments", [])

    col1, col2, col3 = st.columns(3)
    with col1: st.metric("Total Attachments", len(attachments))
    with col2: st.metric("Dangerous Extensions", a.get("dangerous_extension_count", 0))
    with col3: st.metric("Macro-Enabled Files", a.get("macro_enabled_count", 0))

    if attachments:
        for att in attachments:
            fname = att.get("filename", "unknown")
            mime = att.get("mime_type", "–")
            size = att.get("size_bytes", 0)
            ext = "." + fname.rsplit(".", 1)[-1].lower() if "." in fname else ""

            dangerous_exts = {".exe", ".bat", ".cmd", ".com", ".pif", ".scr", ".vbs",
                               ".js", ".ps1", ".hta", ".jar", ".docm", ".xlsm", ".pptm"}
            is_dangerous = ext in dangerous_exts
            color = "#ef4444" if is_dangerous else "#94a3b8"
            icon = "⚠️" if is_dangerous else "📄"

            st.markdown(
                f"<div style='display:flex; justify-content:space-between; align-items:center; "
                f"padding:10px 14px; background:rgba(15,23,42,0.7); border:1px solid "
                f"{'rgba(239,68,68,0.3)' if is_dangerous else '#1e3a5f'}; border-radius:8px; margin:4px 0;'>"
                f"<div>{icon} <span style='color:{color}; font-weight:600;'>{fname}</span>"
                f"<span style='color:#64748b; font-size:0.75rem; margin-left:12px;'>{mime}</span></div>"
                f"<span style='color:#64748b; font-size:0.75rem;'>{size:,} bytes</span>"
                f"</div>",
                unsafe_allow_html=True,
            )
    else:
        st.markdown("<span style='color:#10b981;'>✓ No attachments found</span>", unsafe_allow_html=True)


def _render_sender(s: Dict[str, Any]) -> None:
    col1, col2 = st.columns(2)

    with col1:
        st.markdown("**Sender Analysis**")
        fields = [
            ("Domain", s.get("sender_domain") or "–"),
            ("Domain Age", s.get("domain_age_heuristic", "unknown")),
            ("Free Email Provider", "Yes ⚠️" if s.get("free_email_provider") else "No"),
        ]
        for label, val in fields:
            st.markdown(
                f"<div style='display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid #1e3a5f;'>"
                f"<span style='color:#94a3b8; font-size:0.82rem;'>{label}</span>"
                f"<span style='color:#e2e8f0; font-weight:600; font-size:0.82rem;'>{val}</span>"
                f"</div>",
                unsafe_allow_html=True,
            )

    with col2:
        st.markdown("**Reputation Signals**")

        typo_score = s.get("typosquatting_score", 0)
        typo_color = "#ef4444" if typo_score > 0.7 else "#fbbf24" if typo_score > 0.4 else "#10b981"
        st.markdown(
            f"<div style='padding:8px 0; border-bottom:1px solid #1e3a5f;'>"
            f"<div style='display:flex; justify-content:space-between;'>"
            f"<span style='color:#94a3b8; font-size:0.82rem;'>Typosquatting Score</span>"
            f"<span style='color:{typo_color}; font-weight:600;'>{typo_score:.3f}</span>"
            f"</div>"
            f"<div style='background:#1e3a5f; border-radius:4px; height:4px; margin-top:6px;'>"
            f"<div style='background:{typo_color}; width:{typo_score*100:.0f}%; height:4px; border-radius:4px;'></div>"
            f"</div></div>",
            unsafe_allow_html=True,
        )

        targets = s.get("domain_similarity_targets", [])
        if targets:
            st.markdown(
                f"<div style='padding:8px 0;'>"
                f"<span style='color:#64748b; font-size:0.8rem;'>Similarity targets:</span><br>"
                f"<span style='color:#fbbf24; font-size:0.82rem;'>{', '.join(targets)}</span>"
                f"</div>",
                unsafe_allow_html=True,
            )


def _render_ml_insights(result: Dict[str, Any]) -> None:
    col1, col2 = st.columns([1, 1])

    with col1:
        importance = result.get("ml_feature_importance", {})
        if importance:
            st.markdown("**Top Feature Importances**")
            fig = feature_importance_chart(importance)
            if fig:
                st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("Feature importance not available (rule-based fallback mode)")

    with col2:
        st.markdown("**Score Breakdown**")
        score = result.get("risk_score", 0)
        conf = result.get("confidence", 0)

        breakdown_items = [
            ("ML Risk Score", f"{score:.4f}", "#38bdf8"),
            ("Confidence", f"{conf:.4f}", "#a78bfa"),
            ("Risk Percent", f"{result.get('risk_percent', 0)}%", "#f97316"),
            ("Triage Status", result.get("triage_status", "–").upper(), "#fbbf24"),
        ]

        for label, val, color in breakdown_items:
            st.markdown(
                f"<div style='display:flex; justify-content:space-between; padding:10px 0; border-bottom:1px solid #1e3a5f;'>"
                f"<span style='color:#94a3b8;'>{label}</span>"
                f"<span style='color:{color}; font-family:JetBrains Mono,monospace; font-weight:600;'>{val}</span>"
                f"</div>",
                unsafe_allow_html=True,
            )

        st.markdown("<br>**Raw JSON Result**")
        with st.expander("View full JSON", expanded=False):
            st.json(result)


# ---------------------------------------------------------------------------
# Page: Triage History
# ---------------------------------------------------------------------------

def page_history() -> None:
    st.markdown(
        """
        <h1 style="margin-bottom:4px;">📋 Triage History</h1>
        <p style="color:#64748b; margin-bottom:24px;">All analyzed emails and their triage outcomes</p>
        """,
        unsafe_allow_html=True,
    )

    records = api_triage_history(limit=200)

    if not records:
        st.markdown(
            """
            <div style="text-align:center; padding:60px 20px;">
                <div style="font-size:3rem;">📭</div>
                <h3 style="color:#94a3b8;">No triage records yet</h3>
                <p style="color:#64748b;">Analyze some emails to populate this view.</p>
            </div>
            """,
            unsafe_allow_html=True,
        )
        return

    # Filter controls
    col1, col2, col3 = st.columns(3)
    with col1:
        filter_verdict = st.multiselect(
            "Filter by Verdict",
            ["Safe", "Review", "Suspicious", "Quarantine", "Confirmed Phishing"],
            default=[],
        )
    with col2:
        sort_by = st.selectbox("Sort by", ["timestamp", "risk_score", "verdict"])
    with col3:
        sort_asc = st.checkbox("Ascending", value=False)

    # Apply filters
    filtered = records
    if filter_verdict:
        filtered = [r for r in filtered if r.get("verdict") in filter_verdict]

    filtered = sorted(filtered, key=lambda r: r.get(sort_by, ""), reverse=not sort_asc)

    st.markdown(f"<p style='color:#64748b; font-size:0.85rem;'>Showing {len(filtered)} of {len(records)} records</p>", unsafe_allow_html=True)

    # Table header
    st.markdown(
        """
        <div style="display:grid; grid-template-columns: 2fr 2fr 3fr 1fr 1fr 1.5fr; gap:8px;
             padding:8px 12px; background:rgba(30,58,95,0.3); border-radius:8px 8px 0 0;
             font-size:0.72rem; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; font-weight:600;">
            <div>Timestamp</div>
            <div>Sender</div>
            <div>Subject</div>
            <div>Score</div>
            <div>Verdict</div>
            <div>Status</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    for r in filtered[:100]:
        ts = r.get("timestamp", "")[:19].replace("T", " ")
        sender = (r.get("sender") or "unknown")[:30]
        subject = (r.get("subject") or "–")[:45]
        score = r.get("risk_score", 0)
        v = r.get("verdict", "–")
        status = r.get("triage_status", "–")
        override = r.get("analyst_override")

        v_color = VERDICT_COLOR.get(v, "#94a3b8")
        score_color = "#ef4444" if score > 0.6 else "#fbbf24" if score > 0.3 else "#10b981"
        override_html = (
            f"<span style='font-size:0.65rem; color:#a78bfa; margin-left:6px;'>({override})</span>"
            if override else ""
        )

        st.markdown(
            f"""
            <div style="display:grid; grid-template-columns: 2fr 2fr 3fr 1fr 1fr 1.5fr; gap:8px;
                 padding:9px 12px; border-bottom:1px solid #0f172a;
                 font-size:0.78rem; color:#94a3b8; transition: background 0.1s;"
                 onmouseover="this.style.background='rgba(30,58,95,0.2)'"
                 onmouseout="this.style.background=''">
                <div style="font-family:JetBrains Mono,monospace; font-size:0.72rem;">{ts}</div>
                <div style="word-break:break-all;">{sender}</div>
                <div>{subject}</div>
                <div style="color:{score_color}; font-weight:600; font-family:JetBrains Mono,monospace;">{score:.3f}</div>
                <div style="color:{v_color}; font-weight:600;">{v}</div>
                <div>{status.upper()}{override_html}</div>
            </div>
            """,
            unsafe_allow_html=True,
        )


# ---------------------------------------------------------------------------
# Page: Statistics
# ---------------------------------------------------------------------------

def page_stats() -> None:
    st.markdown(
        """
        <h1 style="margin-bottom:4px;">📈 Statistics Dashboard</h1>
        <p style="color:#64748b; margin-bottom:24px;">Aggregate analysis and threat intelligence overview</p>
        """,
        unsafe_allow_html=True,
    )

    stats = api_triage_stats()
    records = api_triage_history(limit=500)

    if not stats or stats.get("total", 0) == 0:
        st.info("No data yet. Analyze some emails first.")
        return

    # ── Top KPIs ──────────────────────────────────────────────────────────
    k1, k2, k3, k4, k5 = st.columns(5)
    with k1: st.metric("Total Analyzed", stats.get("total", 0))
    with k2: st.metric("Confirmed Phishing", stats.get("confirmed_phishing", 0))
    with k3: st.metric("Quarantine", stats.get("quarantine", 0))
    with k4: st.metric("Phishing Rate", f"{stats.get('phishing_rate', 0)*100:.1f}%")
    with k5: st.metric("Avg Risk Score", f"{stats.get('avg_risk_score', 0)*100:.1f}%")

    st.markdown("<br>", unsafe_allow_html=True)

    col1, col2 = st.columns(2)

    with col1:
        # Verdict distribution pie
        verdict_data = {
            "Safe": stats.get("safe", 0),
            "Review": stats.get("review", 0),
            "Suspicious": stats.get("suspicious", 0),
            "Quarantine": stats.get("quarantine", 0),
            "Confirmed Phishing": stats.get("confirmed_phishing", 0),
        }
        labels = [k for k, v in verdict_data.items() if v > 0]
        values = [v for v in verdict_data.values() if v > 0]
        colors = [VERDICT_COLOR.get(l, "#94a3b8") for l in labels]

        fig_pie = go.Figure(go.Pie(
            labels=labels, values=values,
            marker=dict(colors=colors, line=dict(color="#0a0e1a", width=2)),
            hole=0.5,
            textfont={"color": "#e2e8f0"},
            hoverinfo="label+value+percent",
        ))
        fig_pie.update_layout(
            title=dict(text="Verdict Distribution", font={"color": "#94a3b8", "size": 14}),
            paper_bgcolor="rgba(0,0,0,0)",
            height=320,
            legend=dict(font={"color": "#94a3b8"}, bgcolor="rgba(0,0,0,0)"),
        )
        st.plotly_chart(fig_pie, use_container_width=True)

    with col2:
        # Risk score histogram
        if records:
            scores = [r.get("risk_score", 0) * 100 for r in records]
            fig_hist = go.Figure(go.Histogram(
                x=scores, nbinsx=20,
                marker=dict(
                    color=scores,
                    colorscale=[[0, "#10b981"], [0.4, "#fbbf24"], [0.7, "#f97316"], [1, "#ef4444"]],
                    line=dict(color="#0a0e1a", width=0.5),
                ),
            ))
            fig_hist.update_layout(
                title=dict(text="Risk Score Distribution", font={"color": "#94a3b8", "size": 14}),
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(0,0,0,0)",
                xaxis=dict(title="Risk Score %", gridcolor="#1e3a5f", tickfont={"color": "#64748b"}),
                yaxis=dict(title="Count", gridcolor="#1e3a5f", tickfont={"color": "#64748b"}),
                height=320,
                bargap=0.05,
            )
            st.plotly_chart(fig_hist, use_container_width=True)

    # ── Timeline ─────────────────────────────────────────────────────────
    if records and len(records) > 1:
        import pandas as pd

        df_records = pd.DataFrame(records)
        df_records["ts"] = pd.to_datetime(df_records["timestamp"], errors="coerce")
        df_records = df_records.dropna(subset=["ts"])
        df_records = df_records.sort_values("ts")

        if len(df_records) > 1:
            fig_timeline = px.scatter(
                df_records,
                x="ts",
                y="risk_score",
                color="verdict",
                color_discrete_map={
                    "Safe": "#10b981",
                    "Review": "#60a5fa",
                    "Suspicious": "#fbbf24",
                    "Quarantine": "#f97316",
                    "Confirmed Phishing": "#ef4444",
                },
                hover_data=["sender", "subject"],
                title="Analysis Timeline",
            )
            fig_timeline.update_layout(
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(0,0,0,0)",
                xaxis=dict(gridcolor="#1e3a5f", tickfont={"color": "#64748b"}),
                yaxis=dict(gridcolor="#1e3a5f", tickfont={"color": "#64748b"}, title="Risk Score"),
                legend=dict(font={"color": "#94a3b8"}, bgcolor="rgba(0,0,0,0)"),
                title=dict(font={"color": "#94a3b8"}),
                height=320,
            )
            st.plotly_chart(fig_timeline, use_container_width=True)


# ---------------------------------------------------------------------------
# Page: Model Info
# ---------------------------------------------------------------------------

def page_model_info() -> None:
    st.markdown(
        """
        <h1 style="margin-bottom:4px;">🤖 Model Information</h1>
        <p style="color:#64748b; margin-bottom:24px;">ML model metadata and performance metrics</p>
        """,
        unsafe_allow_html=True,
    )

    info = api_model_info()
    health = api_health()

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("**Model Metadata**")
        meta_items = [
            ("Model Type", info.get("model_type", "–")),
            ("Version", info.get("version", "–")),
            ("Trained At", (info.get("trained_at") or "–")[:19]),
            ("Feature Count", str(info.get("feature_count", "–"))),
            ("Training Samples", str(info.get("training_samples") or "–")),
            ("Status", "✅ Loaded" if health.get("model_loaded") else "⚠️ Fallback (rule-based)"),
        ]
        for label, val in meta_items:
            st.markdown(
                f"<div style='display:flex; justify-content:space-between; padding:10px 0; border-bottom:1px solid #1e3a5f;'>"
                f"<span style='color:#94a3b8;'>{label}</span>"
                f"<span style='color:#e2e8f0; font-weight:600; font-family:JetBrains Mono,monospace;'>{val}</span>"
                f"</div>",
                unsafe_allow_html=True,
            )

    with col2:
        st.markdown("**Performance Metrics**")
        metrics = [
            ("Accuracy", info.get("accuracy")),
            ("Precision", info.get("precision")),
            ("Recall", info.get("recall")),
            ("F1 Score", info.get("f1_score")),
        ]

        for label, val in metrics:
            if val is not None:
                pct = int(val * 100)
                color = "#10b981" if val > 0.9 else "#fbbf24" if val > 0.75 else "#ef4444"
                st.markdown(
                    f"<div style='padding:10px 0; border-bottom:1px solid #1e3a5f;'>"
                    f"<div style='display:flex; justify-content:space-between; margin-bottom:5px;'>"
                    f"<span style='color:#94a3b8;'>{label}</span>"
                    f"<span style='color:{color}; font-weight:700; font-family:JetBrains Mono,monospace;'>{val:.4f}</span>"
                    f"</div>"
                    f"<div style='background:#1e3a5f; border-radius:4px; height:5px;'>"
                    f"<div style='background:{color}; width:{pct}%; height:5px; border-radius:4px;'></div>"
                    f"</div></div>",
                    unsafe_allow_html=True,
                )
            else:
                st.markdown(
                    f"<div style='display:flex; justify-content:space-between; padding:10px 0; border-bottom:1px solid #1e3a5f;'>"
                    f"<span style='color:#94a3b8;'>{label}</span>"
                    f"<span style='color:#64748b;'>N/A (train model first)</span>"
                    f"</div>",
                    unsafe_allow_html=True,
                )

    st.markdown("<br>")
    st.markdown("**Quick Actions**")
    col_a, col_b = st.columns(2)
    with col_a:
        if st.button("🔄 Reload Model from Disk"):
            try:
                r = requests.post(f"{API_V1}/model-reload", timeout=10)
                if r.status_code == 200:
                    st.success("Model reloaded successfully")
                else:
                    st.error("Reload failed")
            except Exception:
                st.error("Cannot reach API")
    with col_b:
        st.info("💡 To retrain: `python scripts/train_model.py`")

    # Feature list
    with st.expander("📋 Feature Engineering Details (32 features)", expanded=False):
        feature_groups = {
            "Header Signals (7)": [
                "from_reply_to_mismatch", "return_path_mismatch", "display_name_spoofing",
                "suspicious_relay", "spf_fail", "dkim_fail", "dmarc_fail",
            ],
            "Body Signals (7)": [
                "urgency_score", "credential_bait_score", "financial_bait_score",
                "social_engineering_score", "html_present", "suspicious_keyword_count", "body_word_count",
            ],
            "URL Signals (10)": [
                "total_urls", "ip_based_urls", "shortener_urls", "suspicious_tlds",
                "punycode_domains", "http_only_urls", "excessive_subdomain_urls",
                "brand_impersonation_urls", "anchor_mismatch_urls", "phishing_url_count",
            ],
            "Attachment Signals (5)": [
                "has_dangerous_attachment", "dangerous_extension_count",
                "macro_enabled_count", "archive_count", "executable_count",
            ],
            "Sender Signals (3)": [
                "typosquatting_score", "free_email_provider", "domain_mismatch_score",
            ],
        }
        for group, features in feature_groups.items():
            st.markdown(f"**{group}**")
            cols = st.columns(3)
            for i, feat in enumerate(features):
                cols[i % 3].markdown(
                    f"<span style='font-family:JetBrains Mono,monospace; font-size:0.75rem; "
                    f"color:#94a3b8;'>{feat}</span>",
                    unsafe_allow_html=True,
                )


# ---------------------------------------------------------------------------
# Sample emails for demo
# ---------------------------------------------------------------------------

PHISHING_SAMPLE = """\
From: "PayPal Security" <security-alert@paypa1-secure.xyz>
Reply-To: noreply@collect-data.ru
Return-Path: <bounce@spam-relay-01.info>
To: victim@company.com
Subject: URGENT: Your PayPal Account Has Been Suspended - Verify Immediately
Date: Mon, 15 May 2024 08:23:11 +0000
X-Mailer: PHPMailer 6.0
Authentication-Results: spf=fail smtp.mailfrom=paypa1-secure.xyz;
  dkim=fail header.d=paypa1-secure.xyz;
  dmarc=fail action=none header.from=paypa1-secure.xyz
Message-ID: <random-9827364@paypa1-secure.xyz>
MIME-Version: 1.0
Content-Type: multipart/alternative; boundary="boundary_alt"

--boundary_alt
Content-Type: text/plain; charset=UTF-8

URGENT NOTICE - YOUR ACCOUNT REQUIRES IMMEDIATE ATTENTION

Dear Valued Customer,

We have detected unusual activity on your PayPal account. Your account has been temporarily suspended due to multiple failed login attempts from an unknown device.

You must verify your identity within 24 hours or your account will be permanently closed and all pending transactions will be cancelled.

CLICK HERE TO VERIFY YOUR ACCOUNT IMMEDIATELY:
http://192.168.1.234/paypal-verify/login.php

Or copy this link: http://bit.ly/2xK9mN3

If you do not respond within 24 hours, we will be forced to permanently limit your account.

To restore full access enter your:
- Email address
- Password
- Credit card details
- Social Security Number

This is your FINAL WARNING. Action required NOW.

PayPal Security Team
security@paypal.com

--boundary_alt
Content-Type: text/html; charset=UTF-8

<html><body>
<p><b>URGENT: Account Suspended</b></p>
<p>Click <a href="http://192.168.1.234/paypal-verify/login.php">here to verify</a> your account now.</p>
<p>Or visit: <a href="http://bit.ly/2xK9mN3">http://www.paypal.com/verify</a></p>
<p>Respond within 24 HOURS or your account will be PERMANENTLY CLOSED.</p>
</body></html>
--boundary_alt--
"""

LEGIT_SAMPLE = """\
From: "GitHub" <noreply@github.com>
Reply-To: noreply@github.com
Return-Path: <noreply@github.com>
To: developer@company.com
Subject: [GitHub] A new SSH key was added to your account
Date: Tue, 16 May 2024 14:30:00 +0000
Authentication-Results: spf=pass smtp.mailfrom=github.com;
  dkim=pass header.d=github.com;
  dmarc=pass action=none header.from=github.com
Message-ID: <notification-123456@github.com>
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8

Hi developer,

A new public key was added to your GitHub account.

Key fingerprint:
SHA256:AbCdEfGhIjKlMnOpQrStUvWxYz1234567890ABCDEF

If you added this SSH key, you can ignore this email.

If you did not add this key, please go to https://github.com/settings/keys and remove it immediately, then visit https://github.com/settings/security to review your recent activity.

For more information, see https://docs.github.com/articles/why-is-git-always-asking-for-my-password/

Thanks,
The GitHub Team

You're receiving this email because of your GitHub account at github.com.
"""


def _render_attack_types(result: Dict[str, Any]) -> None:
    """Render attack type classification results (NEW FEATURE)."""
    
    attack_types = result.get("attack_type_results", {})
    detected_attacks = result.get("detected_attacks", [])
    
    if not attack_types:
        st.info("🎯 Attack type classification not available")
        return
    
    # Show detected attacks summary
    if detected_attacks:
        st.markdown(f"### 🔴 Detected Attack Types ({len(detected_attacks)})")
        st.markdown(", ".join(detected_attacks))
    else:
        st.info("⚠️ No specific attack types detected, but email is suspicious")
    
    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("### Confidence Scores by Attack Type")
    
    # Sort by confidence
    sorted_types = sorted(
        attack_types.items(),
        key=lambda x: x[1]["confidence"],
        reverse=True
    )
    
    for attack_key, attack_data in sorted_types:
        confidence = attack_data.get("confidence", 0)
        status = attack_data.get("status", "Low Evidence")
        name = attack_data.get("name", attack_key)
        indicators = attack_data.get("indicators", [])
        
        # Color based on status
        if status == "Detected":
            color = "#ef4444"  # Red
            emoji = "🔴"
        elif status == "Suspicious":
            color = "#f59e0b"  # Orange
            emoji = "🟡"
        else:
            color = "#10b981"  # Green
            emoji = "🟢"
        
        # Display row
        col1, col2, col3 = st.columns([3, 1, 1])
        
        with col1:
            st.markdown(f"{emoji} **{name}**")
        
        with col2:
            st.progress(confidence / 100.0, text=f"{confidence:.0f}%")
        
        with col3:
            st.markdown(f"<div style='color:{color}; font-weight:bold;'>{status}</div>", unsafe_allow_html=True)
        
        # Show indicators
        if indicators:
            with st.expander(f"View indicators ({confidence:.0f}% confidence)", expanded=False):
                for i, indicator in enumerate(indicators, 1):
                    st.markdown(f"{i}. {indicator}")
    
    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("#### Attack Type Definitions")
    
    definitions = {
        "Credential Theft / Credential Harvesting": "Attacker tries to steal login credentials, passwords, or authentication tokens",
        "Brand Impersonation": "Email spoofs a legitimate company (PayPal, Microsoft, Apple, etc)",
        "Financial / Invoice Fraud": "Attacker requests money transfer, payment, or financial information",
        "Malware Delivery": "Email contains malicious attachments or links to download malware",
        "QR Phishing / Quishing": "Email contains QR code that leads to phishing site when scanned",
        "Account Takeover": "Attacker tries to take over the recipient's account or email",
        "Business Email Compromise (BEC)": "Email impersonates an internal executive or business partner",
        "Generic Social Engineering": "Psychological manipulation to trick recipient into taking action"
    }
    
    with st.expander("📚 What do these attack types mean?", expanded=False):
        for attack_type, definition in definitions.items():
            st.markdown(f"- **{attack_type}:** {definition}")


# ---------------------------------------------------------------------------
# Main router
# ---------------------------------------------------------------------------

def main() -> None:
    # Initialize session state
    if "last_result" not in st.session_state:
        st.session_state["last_result"] = None
    if "pasted_email" not in st.session_state:
        st.session_state["pasted_email"] = ""
    if "active_page" not in st.session_state:
        st.session_state["active_page"] = "🔍 Analyze Email"

    page = sidebar()

    # Allow programmatic page switch
    if st.session_state.get("active_page") and st.session_state["active_page"] != page:
        page = st.session_state["active_page"]
        st.session_state["active_page"] = None

    if page == "🔍 Analyze Email":
        page_analyze()
    elif page == "📊 Analysis Result":
        page_result()
    elif page == "📋 Triage History":
        page_history()
    elif page == "📈 Statistics":
        page_stats()
    elif page == "🤖 Model Info":
        page_model_info()


if __name__ == "__main__":
    main()
