#!/usr/bin/env python3
"""
scripts/train_model.py — Entry point for ML training pipeline.

Usage:
    python scripts/train_model.py
    python scripts/train_model.py --regenerate   # force regenerate dataset
    python scripts/train_model.py --samples 5000  # samples per class
"""
from __future__ import annotations

import argparse
import pathlib
import sys

# Ensure project root is on path
ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from ml.training.train import main as run_training
from ml.datasets.generate_dataset import generate_dataset

DATASET_PATH_DEFAULT = ROOT / "ml" / "datasets" / "synthetic_dataset.csv"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="AI Phishing Triage — Model Training Script"
    )
    parser.add_argument(
        "--regenerate",
        action="store_true",
        help="Force regenerate synthetic dataset even if it exists",
    )
    parser.add_argument(
        "--samples",
        type=int,
        default=3000,
        help="Number of samples per class (default: 3000)",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed (default: 42)",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    if args.regenerate or not DATASET_PATH_DEFAULT.exists():
        print(f"Generating synthetic dataset ({args.samples} samples per class)...")
        generate_dataset(
            n_phishing=args.samples,
            n_legitimate=args.samples,
            output_path=str(DATASET_PATH_DEFAULT),
            seed=args.seed,
        )

    run_training()


if __name__ == "__main__":
    main()
