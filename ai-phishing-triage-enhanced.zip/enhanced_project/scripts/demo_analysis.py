#!/usr/bin/env python3
"""
scripts/demo_analysis.py — Run a quick phishing analysis demo from the CLI.

Usage:
    python scripts/demo_analysis.py
    python scripts/demo_analysis.py --eml path/to/email.eml
"""
from __future__ import annotations

import argparse
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box

console = Console()

PHISHING_SAMPLE = """\
From: "PayPal Security" <security-alert@paypa1-secure.xyz>
Reply-To: noreply@collect-data.ru
Return-Path: <bounce@spam-relay-01.info>
To: victim@company.com
Subject: URGENT: Your PayPal Account Has Been Suspended
Date: Mon, 15 May 2024 08:23:11 +0000
X-Mailer: PHPMailer 6.0
Authentication-Results: spf=fail smtp.mailfrom=paypa1-secure.xyz;
  dkim=fail header.d=paypa1-secure.xyz; dmarc=fail action=none
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8

URGENT NOTICE - YOUR ACCOUNT REQUIRES IMMEDIATE ATTENTION

Dear Valued Customer,

We have detected unusual activity on your PayPal account. Your account
has been temporarily suspended. You must verify your identity within 24
hours or your account will be permanently closed.

CLICK HERE TO VERIFY: http://192.168.1.234/paypal-verify/login.php

Also visit: http://bit.ly/2xK9mN3

Enter your: Email, Password, Credit card details, Social Security Number

This is your FINAL WARNING. Action required NOW.
PayPal Security Team
"""


def print_banner() -> None:
    console.print(Panel(
        "[bold cyan]AI Phishing Email Triage System[/bold cyan]\n"
        "[dim]Defensive Analysis CLI Demo[/dim]",
        style="cyan",
        box=box.DOUBLE_EDGE,
    ))


def verdict_style(verdict: str) -> str:
    styles = {
        "Safe": "bold green",
        "Review": "bold blue",
        "Suspicious": "bold yellow",
        "Quarantine": "bold red",
        "Confirmed Phishing": "bold red on white",
    }
    return styles.get(verdict, "bold white")


def run_analysis(raw_email: str, label: str = "Sample") -> None:
    from backend.services.email_parser import parse_email
    from backend.services.feature_extractor import extract_all_features, build_numeric_feature_vector
    from backend.services.explainability import generate_indicators, compute_rule_based_score
    from backend.services.inference import get_engine
    from backend.services.triage import score_to_verdict, score_to_triage_status

    console.print(f"\n[bold]Analyzing:[/bold] [cyan]{label}[/cyan]")
    console.print("─" * 60)

    # Parse
    parsed = parse_email(raw_email)
    features = extract_all_features(parsed)
    numeric_vec = build_numeric_feature_vector(features)
    rule_score = compute_rule_based_score(features)

    engine = get_engine()
    risk_score, confidence, _ = engine.predict(numeric_vec, rule_score)
    verdict = score_to_verdict(risk_score)
    triage = score_to_triage_status(risk_score)
    indicators = generate_indicators(features)

    # Summary panel
    vstyle = verdict_style(verdict)
    risk_pct = int(risk_score * 100)
    bar_filled = "█" * (risk_pct // 5)
    bar_empty = "░" * (20 - risk_pct // 5)

    console.print(Panel(
        f"[{vstyle}]Verdict: {verdict}[/{vstyle}]\n\n"
        f"Risk Score:  [{('red' if risk_pct > 60 else 'yellow' if risk_pct > 30 else 'green')}]"
        f"{bar_filled}{bar_empty} {risk_pct}%[/]\n"
        f"Confidence:  {confidence*100:.1f}%\n"
        f"Triage:      [bold]{triage.upper()}[/bold]",
        title="[bold]Analysis Result[/bold]",
        style="cyan",
    ))

    # Key metadata
    meta_table = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
    meta_table.add_column("Field", style="dim", min_width=16)
    meta_table.add_column("Value", style="white")
    meta_table.add_row("Subject", parsed.subject or "–")
    meta_table.add_row("From", parsed.from_address or "–")
    meta_table.add_row("Reply-To", parsed.reply_to or "–")
    meta_table.add_row("SPF", parsed.spf_result or "N/A")
    meta_table.add_row("DKIM", parsed.dkim_result or "N/A")
    meta_table.add_row("DMARC", parsed.dmarc_result or "N/A")
    meta_table.add_row("URLs Found", str(len(parsed.urls)))
    meta_table.add_row("Attachments", str(len(parsed.attachments)))
    console.print(meta_table)

    # Indicators
    console.print("\n[bold red]⚠ Phishing Indicators:[/bold red]")
    for i, indicator in enumerate(indicators[:8], 1):
        is_clean = "No significant" in indicator
        icon = "✓" if is_clean else "⚠"
        style = "green" if is_clean else "red"
        console.print(f"  [{style}]{icon}[/{style}] {indicator}")

    console.print()


def main() -> None:
    parser = argparse.ArgumentParser(description="PhishTriage CLI Demo")
    parser.add_argument("--eml", type=str, help="Path to .eml file to analyze")
    args = parser.parse_args()

    print_banner()

    if args.eml:
        eml_path = pathlib.Path(args.eml)
        if not eml_path.exists():
            console.print(f"[red]File not found: {eml_path}[/red]")
            sys.exit(1)
        raw = eml_path.read_text(encoding="utf-8", errors="replace")
        run_analysis(raw, label=eml_path.name)
    else:
        console.print("\n[dim]No --eml file specified. Running built-in phishing demo sample.[/dim]")
        run_analysis(PHISHING_SAMPLE, label="PayPal Phishing Demo")


if __name__ == "__main__":
    main()
