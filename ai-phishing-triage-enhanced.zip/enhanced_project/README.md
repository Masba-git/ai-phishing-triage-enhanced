# 🎣 AI Phishing Email Triage System

A production-grade phishing email analysis and triage platform built for SOC analysts, cybersecurity researchers, and academic demonstration.

---

## Overview

The AI Phishing Email Triage System combines rule-based heuristics with machine learning to analyze emails for phishing indicators. It provides risk scores, analyst-readable explanations, and a full triage workflow — all accessible via a FastAPI backend and a Streamlit SOC-style dashboard.

---

## Features

- **Email Ingestion** — Upload `.eml` files or paste raw email text
- **Header Analysis** — SPF/DKIM/DMARC, Reply-To mismatch, display-name spoofing, relay chain inspection
- **Body Analysis** — Urgency language, credential harvesting patterns, financial bait, social engineering
- **URL Analysis** — IP-based URLs, shorteners, punycode/IDN domains, brand impersonation, anchor mismatch
- **Attachment Analysis** — Dangerous extensions, macro-enabled Office files, executables, archives
- **Sender Reputation** — Typosquatting detection, free provider flagging, domain mismatch scoring
- **ML Classification** — Logistic Regression, Random Forest, XGBoost — best model auto-selected by F1
- **Explainability Engine** — Analyst-readable, specific indicator explanations (not generic)
- **Triage Workflow** — Safe / Review / Suspicious / Quarantine / Confirmed Phishing
- **Analyst Override** — Manual verdict correction with notes
- **History & Stats** — Persistent JSON storage, full statistics dashboard
- **REST API** — FastAPI with OpenAPI docs at `/docs`
- **SOC Dashboard** — Streamlit with dark theme, gauges, radar charts, timeline

---

## Architecture

```
Raw Email (.eml / pasted text)
        │
        ▼
  Email Parser (RFC-5322)
        │
        ├── Header Extractor
        ├── Body Extractor
        ├── URL Extractor
        ├── Attachment Extractor
        └── Sender Analyzer
                │
                ▼
      Feature Engineering (32 numeric features)
                │
           ┌────┴────┐
           │         │
    Rule-based    ML Model
     Scoring    (XGBoost / RF / LR)
           │         │
           └────┬────┘
                │  (70% ML + 30% rule blend)
                ▼
       Risk Score (0.0 – 1.0)
                │
                ▼
    Explainability Engine
    (ranked analyst indicators)
                │
                ▼
       Triage Assignment
    (Safe / Quarantine / etc.)
                │
                ▼
     TinyDB Persistence + API Response
```

---

## Project Structure

```
ai-phishing-triage/
├── backend/
│   ├── api/
│   │   └── routes.py           # All FastAPI endpoints
│   ├── models/
│   │   └── schemas.py          # Pydantic request/response models
│   ├── services/
│   │   ├── analyzer.py         # Pipeline orchestrator
│   │   ├── email_parser.py     # RFC-5322 email parser
│   │   ├── explainability.py   # Indicator generation engine
│   │   ├── feature_extractor.py# Feature engineering
│   │   ├── inference.py        # ML inference engine
│   │   └── triage.py           # Verdict + DB persistence
│   └── main.py                 # FastAPI application
├── dashboard/
│   └── app.py                  # Streamlit SOC dashboard
├── ml/
│   ├── datasets/
│   │   └── generate_dataset.py # Synthetic data generator
│   ├── feature_engineering/
│   │   └── features.py         # Canonical 32-feature schema
│   └── training/
│       └── train.py            # Full training pipeline
├── scripts/
│   ├── train_model.py          # CLI training entrypoint
│   └── demo_analysis.py        # CLI demo (no UI needed)
├── tests/
│   ├── test_email_parser.py
│   └── test_features.py
├── utils/
│   ├── config.py               # Settings (pydantic-settings)
│   └── logger.py               # Loguru logger
├── saved_models/               # Trained model saved here
├── data/                       # TinyDB triage history
├── requirements.txt
├── .env.example
└── pyproject.toml
```

---

## Installation

### Prerequisites

- Python 3.10 or higher
- pip

### 1. Clone / Copy the project

```bash
# If cloned from GitHub:
git clone https://github.com/yourname/ai-phishing-triage.git
cd ai-phishing-triage

# Or just cd into the folder you copied:
cd ai-phishing-triage
```

### 2. Create virtual environment

**Linux / macOS:**
```bash
python3 -m venv venv
source venv/bin/activate
```

**Windows:**
```cmd
python -m venv venv
venv\Scripts\activate 

```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Copy environment file

```bash
cp .env.example .env
```

---

## Training the ML Model

Run the training pipeline (generates synthetic dataset + trains 3 models + saves best):

```bash
python scripts/train_model.py
```

Options:
```bash
python scripts/train_model.py --samples 5000       # 5000 samples per class
python scripts/train_model.py --regenerate         # Force regenerate dataset
python scripts/train_model.py --samples 5000 --seed 123
```

Expected output:
```
Generating synthetic dataset...
Dataset saved: ml/datasets/synthetic_dataset.csv (6000 samples)

Training: LogisticRegression
  Accuracy: 0.9317  F1: 0.9312

Training: RandomForest
  Accuracy: 0.9750  F1: 0.9748

Training: XGBoost
  Accuracy: 0.9817  F1: 0.9815  ← BEST

✅ Best model saved: saved_models/phishing_model.joblib
```

---

## Running the API

```bash
uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload
```

API docs: [http://localhost:8000/docs](http://localhost:8000/docs)  
Health check: [http://localhost:8000/api/v1/health](http://localhost:8000/api/v1/health)

---

## Running the Dashboard

In a second terminal (keep API running):

```bash
streamlit run dashboard/app.py --server.port 8501
```

Dashboard: [http://localhost:8501](http://localhost:8501)

---

## API Reference

### `GET /api/v1/health`
```json
{
  "status": "ok",
  "model_loaded": true,
  "version": "1.0.0",
  "timestamp": "2024-05-15T10:00:00Z"
}
```

### `POST /api/v1/analyze`
```bash
curl -X POST http://localhost:8000/api/v1/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "raw_email": "From: attacker@evil.xyz\nSubject: Urgent\n\nClick here: http://bit.ly/abc"
  }'
```

Response includes: `risk_score`, `verdict`, `top_indicators`, `headers`, `body`, `urls`, `attachments`, `sender`, `triage_status`

### `POST /api/v1/analyze-file`
```bash
curl -X POST http://localhost:8000/api/v1/analyze-file \
  -F "file=@/path/to/email.eml"
```

### `POST /api/v1/analyze-batch`
```bash
curl -X POST http://localhost:8000/api/v1/analyze-batch \
  -H "Content-Type: application/json" \
  -d '{"emails": [{"raw_email": "..."}, {"raw_email": "..."}]}'
```

### `GET /api/v1/triage-history`
```bash
curl http://localhost:8000/api/v1/triage-history?limit=50
```

### `GET /api/v1/triage-stats`
```bash
curl http://localhost:8000/api/v1/triage-stats
```

### `GET /api/v1/model-info`
```bash
curl http://localhost:8000/api/v1/model-info
```

### `POST /api/v1/triage-update`
```bash
curl -X POST http://localhost:8000/api/v1/triage-update \
  -H "Content-Type: application/json" \
  -d '{"analysis_id": "uuid-here", "analyst_override": "confirmed_phishing", "analyst_note": "Spear phishing targeting finance"}'
```

---

## CLI Demo (no UI required)

```bash
# Run built-in phishing demo
python scripts/demo_analysis.py

# Analyze a real .eml file
python scripts/demo_analysis.py --eml /path/to/email.eml
```

---

## Running Tests

```bash
pytest tests/ -v
```

---

## ML Feature Schema

| Group | Count | Examples |
|-------|-------|---------|
| Header | 7 | `spf_fail`, `from_reply_to_mismatch`, `display_name_spoofing` |
| Body | 7 | `urgency_score`, `credential_bait_score`, `financial_bait_score` |
| URL | 10 | `ip_based_urls`, `shortener_urls`, `brand_impersonation_urls` |
| Attachment | 5 | `macro_enabled_count`, `executable_count`, `has_dangerous_attachment` |
| Sender | 3 | `typosquatting_score`, `free_email_provider`, `domain_mismatch_score` |

---

## Risk Thresholds

| Score Range | Verdict | Triage Status |
|------------|---------|--------------|
| 0.00 – 0.20 | Safe | safe |
| 0.20 – 0.40 | Review | review |
| 0.40 – 0.60 | Suspicious | suspicious |
| 0.60 – 0.80 | Quarantine | quarantine |
| 0.80 – 1.00 | Confirmed Phishing | quarantine |

Thresholds are configurable via `.env`.

---

## Troubleshooting

**API won't start:**
```bash
pip install -r requirements.txt
python -c "import fastapi, uvicorn; print('OK')"
```

**Model not loaded (rule-based fallback):**
```bash
python scripts/train_model.py
# Then reload via API: POST /api/v1/model-reload
```

**Dashboard can't connect to API:**
- Ensure API is running: `uvicorn backend.main:app --port 8000`
- Check `API_BASE_URL` in `.env` matches your API host/port

**XGBoost not available:**
```bash
pip install xgboost
```

**spaCy model missing (if used):**
```bash
python -m spacy download en_core_web_sm
```

---

## Screenshots

> _Add screenshots here for your defense presentation_

- `screenshots/dashboard_analysis.png` — Analysis result page
- `screenshots/dashboard_stats.png` — Statistics panel
- `screenshots/dashboard_history.png` — Triage history
- `screenshots/api_docs.png` — FastAPI Swagger UI

---

## Future Improvements

- Integration with VirusTotal API for live URL scanning
- YARA rule engine for attachment scanning
- Active Directory / LDAP integration for sender lookup
- Email forwarding via IMAP/Exchange connector
- Role-based access control (RBAC) for multi-analyst teams
- Real phishing dataset integration (CEAS-08, PhishTank, OpenPhish)
- MITRE ATT&CK tactic tagging
- Webhook/SIEM integration (Splunk, QRadar)
- Docker Compose deployment

---

## Disclaimer

This project is strictly **defensive**. It is designed to detect and analyze phishing emails, not to create them. All analysis is performed on emails submitted by the user for defensive review purposes.

---

## License

MIT License — free for academic, research, and commercial defensive security use.
