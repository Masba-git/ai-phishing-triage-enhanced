"""
ML Training Pipeline — AI Phishing Triage System.

Trains and evaluates multiple classifiers on the phishing feature dataset.
Saves the best model (by F1-score) as a joblib bundle.

Models trained:
  - Logistic Regression (baseline)
  - Random Forest
  - XGBoost (if available)

Outputs:
  - saved_models/phishing_model.joblib   ← best model bundle
  - training report printed to console
"""
from __future__ import annotations

import json
import pathlib
import sys
import warnings
from datetime import datetime, timezone
from typing import Any, Dict, List, Tuple

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, classification_report, confusion_matrix,
    f1_score, precision_score, recall_score,
)
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore")

# Add project root to path
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent.parent))

try:
    from xgboost import XGBClassifier
    XGBOOST_AVAILABLE = True
except ImportError:
    XGBOOST_AVAILABLE = False
    print("[WARNING] XGBoost not installed — will train Logistic Regression + Random Forest only")

from ml.datasets.generate_dataset import generate_dataset, FEATURE_NAMES


# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
ROOT = pathlib.Path(__file__).resolve().parent.parent.parent
DATASET_PATH = ROOT / "ml" / "datasets" / "synthetic_dataset.csv"
MODEL_OUTPUT_PATH = ROOT / "saved_models" / "phishing_model.joblib"
MODEL_OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

def load_or_generate_dataset() -> pd.DataFrame:
    if DATASET_PATH.exists():
        print(f"Loading existing dataset: {DATASET_PATH}")
        df = pd.read_csv(DATASET_PATH)
    else:
        print("No dataset found — generating synthetic dataset...")
        df = generate_dataset(
            n_phishing=3000,
            n_legitimate=3000,
            output_path=str(DATASET_PATH),
        )
    print(f"Dataset shape: {df.shape} | Phishing: {df['label'].sum()} | Legit: {(df['label'] == 0).sum()}")
    return df


# ---------------------------------------------------------------------------
# Model definitions
# ---------------------------------------------------------------------------

def build_models() -> List[Tuple[str, Any]]:
    """Return list of (name, pipeline) to train and evaluate."""
    lr_pipeline = Pipeline([
        ("scaler", StandardScaler()),
        ("clf", LogisticRegression(
            C=1.0, max_iter=1000, class_weight="balanced",
            solver="lbfgs", random_state=42,
        )),
    ])

    rf_pipeline = Pipeline([
        ("scaler", StandardScaler()),
        ("clf", RandomForestClassifier(
            n_estimators=200, max_depth=12, min_samples_leaf=2,
            class_weight="balanced", random_state=42, n_jobs=-1,
        )),
    ])

    models = [
        ("LogisticRegression", lr_pipeline),
        ("RandomForest", rf_pipeline),
    ]

    if XGBOOST_AVAILABLE:
        xgb_pipeline = Pipeline([
            ("scaler", StandardScaler()),
            ("clf", XGBClassifier(
                n_estimators=200,
                max_depth=6,
                learning_rate=0.1,
                subsample=0.8,
                colsample_bytree=0.8,
                scale_pos_weight=1,
                use_label_encoder=False,
                eval_metric="logloss",
                random_state=42,
                n_jobs=-1,
            )),
        ])
        models.append(("XGBoost", xgb_pipeline))

    return models


# ---------------------------------------------------------------------------
# Evaluation
# ---------------------------------------------------------------------------

def evaluate_model(
    name: str,
    pipeline: Any,
    X_train: np.ndarray,
    X_test: np.ndarray,
    y_train: np.ndarray,
    y_test: np.ndarray,
) -> Dict[str, Any]:
    """Train and evaluate a single pipeline. Returns metrics dict."""
    print(f"\n{'='*50}")
    print(f"Training: {name}")
    print(f"{'='*50}")

    pipeline.fit(X_train, y_train)
    y_pred = pipeline.predict(X_test)
    y_proba = pipeline.predict_proba(X_test)[:, 1]

    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, zero_division=0)
    rec = recall_score(y_test, y_pred, zero_division=0)
    f1 = f1_score(y_test, y_pred, zero_division=0)
    cm = confusion_matrix(y_test, y_pred).tolist()

    print(f"Accuracy:  {acc:.4f}")
    print(f"Precision: {prec:.4f}")
    print(f"Recall:    {rec:.4f}")
    print(f"F1-Score:  {f1:.4f}")
    print("\nConfusion Matrix (Legit / Phishing):")
    print(f"  TN={cm[0][0]}  FP={cm[0][1]}")
    print(f"  FN={cm[1][0]}  TP={cm[1][1]}")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred, target_names=["Legitimate", "Phishing"]))

    # 5-fold cross-validation on full data
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    X_full = np.vstack([X_train, X_test])
    y_full = np.concatenate([y_train, y_test])
    cv_f1 = cross_val_score(pipeline, X_full, y_full, cv=cv, scoring="f1", n_jobs=-1)
    print(f"\nCV F1 (5-fold): {cv_f1.mean():.4f} ± {cv_f1.std():.4f}")

    return {
        "model_type": name,
        "pipeline": pipeline,
        "accuracy": round(float(acc), 4),
        "precision": round(float(prec), 4),
        "recall": round(float(rec), 4),
        "f1_score": round(float(f1), 4),
        "cv_f1_mean": round(float(cv_f1.mean()), 4),
        "cv_f1_std": round(float(cv_f1.std()), 4),
        "confusion_matrix": cm,
    }


# ---------------------------------------------------------------------------
# Save best model
# ---------------------------------------------------------------------------

def save_model(best: Dict[str, Any], training_samples: int) -> None:
    bundle = {
        "model": best["pipeline"],
        "meta": {
            "model_type": best["model_type"],
            "version": "1.0.0",
            "trained_at": datetime.now(timezone.utc).isoformat(),
            "accuracy": best["accuracy"],
            "precision": best["precision"],
            "recall": best["recall"],
            "f1_score": best["f1_score"],
            "cv_f1_mean": best["cv_f1_mean"],
            "feature_names": FEATURE_NAMES,
            "training_samples": training_samples,
        },
    }
    joblib.dump(bundle, MODEL_OUTPUT_PATH, compress=3)
    print(f"\n✅ Best model saved: {MODEL_OUTPUT_PATH}")
    print(f"   Model: {best['model_type']} | F1: {best['f1_score']:.4f}")


# ---------------------------------------------------------------------------
# Main training script
# ---------------------------------------------------------------------------

def main() -> None:
    print("\n" + "=" * 60)
    print("  AI Phishing Triage — ML Training Pipeline")
    print("=" * 60 + "\n")

    # 1. Load data
    df = load_or_generate_dataset()
    X = df[FEATURE_NAMES].values.astype(np.float32)
    y = df["label"].values.astype(int)

    # 2. Train/test split — stratified
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=42
    )
    print(f"\nTrain size: {len(X_train)} | Test size: {len(X_test)}")

    # 3. Build and evaluate all models
    models = build_models()
    results: List[Dict[str, Any]] = []

    for name, pipeline in models:
        metrics = evaluate_model(name, pipeline, X_train, X_test, y_train, y_test)
        results.append(metrics)

    # 4. Select best model by F1
    best = max(results, key=lambda r: r["f1_score"])

    print("\n" + "=" * 60)
    print("Model Comparison Summary")
    print("=" * 60)
    print(f"{'Model':<25} {'Acc':>8} {'Prec':>8} {'Rec':>8} {'F1':>8}")
    print("-" * 60)
    for r in results:
        marker = " ← BEST" if r["model_type"] == best["model_type"] else ""
        print(
            f"{r['model_type']:<25} "
            f"{r['accuracy']:>8.4f} "
            f"{r['precision']:>8.4f} "
            f"{r['recall']:>8.4f} "
            f"{r['f1_score']:>8.4f}{marker}"
        )

    # 5. Save best
    save_model(best, training_samples=len(X_train))

    print("\n✅ Training complete.\n")


if __name__ == "__main__":
    main()
