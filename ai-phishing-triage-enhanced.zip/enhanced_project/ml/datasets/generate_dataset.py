"""
Synthetic phishing email dataset generator.

Generates realistic numeric feature vectors for ML training
when real labelled datasets are unavailable.

Structure is designed so real datasets (CEAS-08, SpamAssassin, etc.)
can be substituted by producing the same CSV column schema.

CSV columns: [feature_names..., label]
label: 1 = phishing, 0 = legitimate
"""
from __future__ import annotations

import pathlib
import random
from typing import List, Tuple

import numpy as np
import pandas as pd

FEATURE_NAMES = [
    "from_reply_to_mismatch",
    "return_path_mismatch",
    "display_name_spoofing",
    "suspicious_relay",
    "spf_fail",
    "dkim_fail",
    "dmarc_fail",
    "urgency_score",
    "credential_bait_score",
    "financial_bait_score",
    "social_engineering_score",
    "html_present",
    "suspicious_keyword_count",
    "body_word_count",
    "total_urls",
    "ip_based_urls",
    "shortener_urls",
    "suspicious_tlds",
    "punycode_domains",
    "http_only_urls",
    "excessive_subdomain_urls",
    "brand_impersonation_urls",
    "anchor_mismatch_urls",
    "phishing_url_count",
    "has_dangerous_attachment",
    "dangerous_extension_count",
    "macro_enabled_count",
    "archive_count",
    "executable_count",
    "typosquatting_score",
    "free_email_provider",
    "domain_mismatch_score",
]


def _rng_float(lo: float, hi: float) -> float:
    return round(random.uniform(lo, hi), 4)


def _rng_bool(prob_true: float) -> float:
    return 1.0 if random.random() < prob_true else 0.0


def generate_phishing_sample() -> List[float]:
    """Generate a feature vector for a phishing email."""
    # Header signals — high for phishing
    from_reply_mismatch   = _rng_bool(0.70)
    return_path_mismatch  = _rng_bool(0.60)
    display_name_spoof    = _rng_bool(0.65)
    suspicious_relay      = _rng_bool(0.40)
    spf_fail              = _rng_bool(0.65)
    dkim_fail             = _rng_bool(0.60)
    dmarc_fail            = _rng_bool(0.60)

    # Body signals
    urgency_score         = _rng_float(0.3, 1.0)
    cred_bait_score       = _rng_float(0.3, 1.0)
    financial_bait_score  = _rng_float(0.2, 1.0)
    social_eng_score      = _rng_float(0.3, 1.0)
    html_present          = _rng_bool(0.80)
    suspicious_kw_count   = _rng_float(0.3, 1.0)   # normalized
    body_word_count       = _rng_float(0.05, 0.6)

    # URL signals
    total_urls            = _rng_float(0.05, 0.8)
    ip_based_urls         = _rng_bool(0.35)
    shortener_urls        = _rng_bool(0.45)
    suspicious_tlds_val   = _rng_bool(0.50)
    punycode_domains_val  = _rng_bool(0.25)
    http_only_urls        = _rng_float(0.1, 0.9)
    excessive_subdomain   = _rng_bool(0.40)
    brand_impersonation   = _rng_bool(0.55)
    anchor_mismatch       = _rng_bool(0.50)
    phishing_url_count    = _rng_float(0.1, 1.0)

    # Attachment signals
    has_dangerous_att     = _rng_bool(0.35)
    dangerous_ext_count   = _rng_float(0.0, 0.8) if has_dangerous_att else 0.0
    macro_enabled         = _rng_float(0.0, 0.8) if has_dangerous_att and random.random() > 0.5 else 0.0
    archive_count         = _rng_float(0.0, 0.6) if has_dangerous_att else 0.0
    exe_count             = _rng_float(0.0, 0.6) if has_dangerous_att and random.random() > 0.6 else 0.0

    # Sender signals
    typosquatting_score   = _rng_float(0.3, 0.99)
    free_email_provider   = _rng_bool(0.50)
    domain_mismatch_score = _rng_float(0.3, 0.99)

    return [
        from_reply_mismatch, return_path_mismatch, display_name_spoof,
        suspicious_relay, spf_fail, dkim_fail, dmarc_fail,
        urgency_score, cred_bait_score, financial_bait_score, social_eng_score,
        html_present, suspicious_kw_count, body_word_count,
        total_urls, ip_based_urls, shortener_urls, suspicious_tlds_val,
        punycode_domains_val, http_only_urls, excessive_subdomain,
        brand_impersonation, anchor_mismatch, phishing_url_count,
        has_dangerous_att, dangerous_ext_count, macro_enabled,
        archive_count, exe_count,
        typosquatting_score, free_email_provider, domain_mismatch_score,
    ]


def generate_legitimate_sample() -> List[float]:
    """Generate a feature vector for a legitimate email."""
    from_reply_mismatch   = _rng_bool(0.05)
    return_path_mismatch  = _rng_bool(0.05)
    display_name_spoof    = _rng_bool(0.02)
    suspicious_relay      = _rng_bool(0.10)
    spf_fail              = _rng_bool(0.10)
    dkim_fail             = _rng_bool(0.08)
    dmarc_fail            = _rng_bool(0.08)

    urgency_score         = _rng_float(0.0, 0.15)
    cred_bait_score       = _rng_float(0.0, 0.10)
    financial_bait_score  = _rng_float(0.0, 0.20)
    social_eng_score      = _rng_float(0.0, 0.15)
    html_present          = _rng_bool(0.60)
    suspicious_kw_count   = _rng_float(0.0, 0.15)
    body_word_count       = _rng_float(0.1, 0.9)

    total_urls            = _rng_float(0.0, 0.3)
    ip_based_urls         = _rng_bool(0.01)
    shortener_urls        = _rng_bool(0.05)
    suspicious_tlds_val   = _rng_bool(0.02)
    punycode_domains_val  = _rng_bool(0.01)
    http_only_urls        = _rng_float(0.0, 0.2)
    excessive_subdomain   = _rng_bool(0.05)
    brand_impersonation   = _rng_bool(0.02)
    anchor_mismatch       = _rng_bool(0.03)
    phishing_url_count    = _rng_float(0.0, 0.05)

    has_dangerous_att     = _rng_bool(0.03)
    dangerous_ext_count   = _rng_float(0.0, 0.2) if has_dangerous_att else 0.0
    macro_enabled         = 0.0
    archive_count         = _rng_float(0.0, 0.3)
    exe_count             = 0.0

    typosquatting_score   = _rng_float(0.0, 0.2)
    free_email_provider   = _rng_bool(0.30)
    domain_mismatch_score = _rng_float(0.0, 0.15)

    return [
        from_reply_mismatch, return_path_mismatch, display_name_spoof,
        suspicious_relay, spf_fail, dkim_fail, dmarc_fail,
        urgency_score, cred_bait_score, financial_bait_score, social_eng_score,
        html_present, suspicious_kw_count, body_word_count,
        total_urls, ip_based_urls, shortener_urls, suspicious_tlds_val,
        punycode_domains_val, http_only_urls, excessive_subdomain,
        brand_impersonation, anchor_mismatch, phishing_url_count,
        has_dangerous_att, dangerous_ext_count, macro_enabled,
        archive_count, exe_count,
        typosquatting_score, free_email_provider, domain_mismatch_score,
    ]


def generate_dataset(
    n_phishing: int = 3000,
    n_legitimate: int = 3000,
    output_path: str = "ml/datasets/synthetic_dataset.csv",
    seed: int = 42,
) -> pd.DataFrame:
    """
    Generate balanced synthetic dataset and save as CSV.

    Args:
        n_phishing: Number of phishing samples
        n_legitimate: Number of legitimate samples
        output_path: Where to save the CSV
        seed: Random seed for reproducibility

    Returns:
        pandas DataFrame with features + label column
    """
    random.seed(seed)
    np.random.seed(seed)

    rows: List[List[float]] = []
    labels: List[int] = []

    print(f"Generating {n_phishing} phishing samples...")
    for _ in range(n_phishing):
        rows.append(generate_phishing_sample())
        labels.append(1)

    print(f"Generating {n_legitimate} legitimate samples...")
    for _ in range(n_legitimate):
        rows.append(generate_legitimate_sample())
        labels.append(0)

    df = pd.DataFrame(rows, columns=FEATURE_NAMES)
    df["label"] = labels

    # Shuffle
    df = df.sample(frac=1, random_state=seed).reset_index(drop=True)

    # Save
    output = pathlib.Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output, index=False)
    print(f"Dataset saved: {output} ({len(df)} samples, {df['label'].sum()} phishing)")

    return df


if __name__ == "__main__":
    generate_dataset()
