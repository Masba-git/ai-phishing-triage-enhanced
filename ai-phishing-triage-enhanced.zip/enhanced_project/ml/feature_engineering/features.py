"""
Feature engineering documentation.

This module documents and exports the canonical feature set used
for both training and inference. Keeping this in one place ensures
training/inference parity — the exact same features must be used in both.

Feature groups:
  1. Header features    (7 features)
  2. Body features      (7 features)
  3. URL features       (10 features)
  4. Attachment features (5 features)
  5. Sender features    (3 features)

Total: 32 numeric features

All values are normalized to [0.0, 1.0] range.
Binary features are represented as 0.0 or 1.0.
"""

FEATURE_NAMES = [
    # -------------------------
    # Group 1: Header signals
    # -------------------------
    "from_reply_to_mismatch",     # Binary: Reply-To domain ≠ From domain
    "return_path_mismatch",       # Binary: Return-Path domain ≠ From domain
    "display_name_spoofing",      # Binary: Display name claims trusted brand, domain doesn't match
    "suspicious_relay",           # Binary: >6 hops in Received chain
    "spf_fail",                   # Binary: SPF=fail or softfail
    "dkim_fail",                  # Binary: DKIM=fail
    "dmarc_fail",                 # Binary: DMARC=fail

    # -------------------------
    # Group 2: Body signals
    # -------------------------
    "urgency_score",              # Float [0,1]: Urgency/pressure language density
    "credential_bait_score",      # Float [0,1]: Credential harvesting language density
    "financial_bait_score",       # Float [0,1]: Financial lure language density
    "social_engineering_score",   # Float [0,1]: Social engineering pattern density
    "html_present",               # Binary: HTML body present
    "suspicious_keyword_count",   # Float [0,1]: Normalized count of phishing keywords
    "body_word_count",            # Float [0,1]: Normalized word count (saturates at 1000)

    # -------------------------
    # Group 3: URL signals
    # -------------------------
    "total_urls",                 # Float [0,1]: Normalized URL count
    "ip_based_urls",              # Float [0,1]: Normalized count of IP-based URLs
    "shortener_urls",             # Float [0,1]: Normalized count of URL shortener URLs
    "suspicious_tlds",            # Float [0,1]: Normalized count of suspicious TLD URLs
    "punycode_domains",           # Float [0,1]: Normalized count of punycode/IDN URLs
    "http_only_urls",             # Float [0,1]: Normalized count of HTTP (no HTTPS) URLs
    "excessive_subdomain_urls",   # Float [0,1]: Normalized count of excessive subdomain URLs
    "brand_impersonation_urls",   # Float [0,1]: Normalized count of brand impersonation URLs
    "anchor_mismatch_urls",       # Float [0,1]: Normalized count of anchor text mismatch URLs
    "phishing_url_count",         # Float [0,1]: Overall phishing URL signal

    # -------------------------
    # Group 4: Attachment signals
    # -------------------------
    "has_dangerous_attachment",   # Binary: Any dangerous extension present
    "dangerous_extension_count",  # Float [0,1]: Normalized dangerous attachment count
    "macro_enabled_count",        # Float [0,1]: Normalized macro-enabled file count
    "archive_count",              # Float [0,1]: Normalized archive attachment count
    "executable_count",           # Float [0,1]: Normalized executable count

    # -------------------------
    # Group 5: Sender signals
    # -------------------------
    "typosquatting_score",        # Float [0,1]: Similarity to trusted domain (typosquatting)
    "free_email_provider",        # Binary: Sent from free webmail service
    "domain_mismatch_score",      # Float [0,1]: Domain reputation mismatch score
]

FEATURE_COUNT = len(FEATURE_NAMES)
FEATURE_GROUPS = {
    "header": FEATURE_NAMES[:7],
    "body": FEATURE_NAMES[7:14],
    "url": FEATURE_NAMES[14:24],
    "attachment": FEATURE_NAMES[24:29],
    "sender": FEATURE_NAMES[29:],
}
