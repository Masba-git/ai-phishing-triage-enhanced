"""
FastAPI router — all API endpoints for the phishing triage system.
"""
from __future__ import annotations

import io
from datetime import datetime, timezone
from typing import Any, Dict, List

from fastapi import APIRouter, File, Form, HTTPException, UploadFile, status

from backend.models.schemas import (
    AnalyzeRequest, AnalysisResult, BatchAnalyzeRequest, BatchAnalyzeResponse,
    HealthResponse, ModelInfo, TriageRecord, TriageUpdateRequest,
)
from backend.services.analyzer import analyze_email
from backend.services.triage import get_triage_history, get_triage_stats, update_triage_record
from backend.services.inference import get_engine, reload_engine
from utils.logger import logger

router = APIRouter()


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

@router.get(
    "/health",
    response_model=HealthResponse,
    summary="System health check",
    tags=["System"],
)
def health() -> HealthResponse:
    """Returns current system health and model status."""
    engine = get_engine()
    return HealthResponse(
        status="ok",
        model_loaded=engine.is_loaded(),
        version="1.0.0",
        timestamp=datetime.now(timezone.utc).isoformat(),
    )


# ---------------------------------------------------------------------------
# Analyze single email (JSON body)
# ---------------------------------------------------------------------------

@router.post(
    "/analyze",
    response_model=AnalysisResult,
    summary="Analyze a single email",
    tags=["Analysis"],
)
def analyze(request: AnalyzeRequest) -> AnalysisResult:
    """
    Analyze a raw email string for phishing indicators.

    - Accepts RFC-5322 email text or pasted body text
    - Returns full analysis including risk score, verdict, indicators, triage status
    """
    if not request.raw_email or not request.raw_email.strip():
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="raw_email must not be empty",
        )
    try:
        result = analyze_email(
            raw_email=request.raw_email,
            filename=request.filename,
            analyst_note=request.analyst_note,
        )
        return result
    except Exception as exc:
        logger.exception(f"Analysis failed: {exc}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Analysis pipeline error: {str(exc)}",
        )


# ---------------------------------------------------------------------------
# Analyze .eml file upload
# ---------------------------------------------------------------------------

@router.post(
    "/analyze-file",
    response_model=AnalysisResult,
    summary="Analyze an uploaded .eml file",
    tags=["Analysis"],
)
async def analyze_file(
    file: UploadFile = File(..., description="RFC-5322 .eml file"),
    analyst_note: str = Form(default=""),
) -> AnalysisResult:
    """Upload a .eml file for phishing analysis."""
    if not file.filename:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="No file provided",
        )

    allowed_extensions = {".eml", ".txt", ".msg"}
    import pathlib
    ext = pathlib.Path(file.filename).suffix.lower()
    if ext not in allowed_extensions:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Unsupported file type: {ext}. Allowed: {allowed_extensions}",
        )

    try:
        raw_bytes = await file.read()
        # Try common email encodings
        for enc in ("utf-8", "latin-1", "ascii"):
            try:
                raw_email = raw_bytes.decode(enc)
                break
            except UnicodeDecodeError:
                continue
        else:
            raw_email = raw_bytes.decode("utf-8", errors="replace")

        result = analyze_email(
            raw_email=raw_email,
            filename=file.filename,
            analyst_note=analyst_note or None,
        )
        return result
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception(f"File analysis failed: {exc}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"File analysis error: {str(exc)}",
        )


# ---------------------------------------------------------------------------
# Batch analysis
# ---------------------------------------------------------------------------

@router.post(
    "/analyze-batch",
    response_model=BatchAnalyzeResponse,
    summary="Analyze multiple emails in one request",
    tags=["Analysis"],
)
def analyze_batch(request: BatchAnalyzeRequest) -> BatchAnalyzeResponse:
    """
    Analyze a list of emails in a single API call.
    Max 50 emails per request to prevent timeout.
    """
    if not request.emails:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="emails list must not be empty",
        )
    if len(request.emails) > 50:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail="Maximum 50 emails per batch request",
        )

    results: List[AnalysisResult] = []
    for email_req in request.emails:
        try:
            result = analyze_email(
                raw_email=email_req.raw_email,
                filename=email_req.filename,
                analyst_note=email_req.analyst_note,
            )
            results.append(result)
        except Exception as exc:
            logger.error(f"Batch item failed: {exc}")

    return BatchAnalyzeResponse(total=len(results), results=results)


# ---------------------------------------------------------------------------
# Model info
# ---------------------------------------------------------------------------

@router.get(
    "/model-info",
    response_model=ModelInfo,
    summary="Get ML model information",
    tags=["Model"],
)
def model_info() -> ModelInfo:
    """Returns metadata about the loaded ML model."""
    engine = get_engine()
    info = engine.get_model_info()
    return ModelInfo(**info)


@router.post(
    "/model-reload",
    summary="Reload model from disk",
    tags=["Model"],
)
def model_reload() -> Dict[str, str]:
    """Force-reload the ML model (useful after retraining)."""
    reload_engine()
    engine = get_engine()
    return {
        "status": "reloaded",
        "model_loaded": str(engine.is_loaded()),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


# ---------------------------------------------------------------------------
# Triage history
# ---------------------------------------------------------------------------

@router.get(
    "/triage-history",
    summary="Get triage history",
    tags=["Triage"],
)
def triage_history(limit: int = 100) -> Dict[str, Any]:
    """Returns recent triage records sorted by timestamp descending."""
    records = get_triage_history(limit=min(limit, 500))
    return {"total": len(records), "records": records}


@router.post(
    "/triage-update",
    summary="Apply analyst override to a triage record",
    tags=["Triage"],
)
def triage_update(request: TriageUpdateRequest) -> Dict[str, Any]:
    """
    Apply an analyst verdict override.

    Allowed override values: safe, review, suspicious, quarantine, confirmed_phishing
    """
    allowed = {"safe", "review", "suspicious", "quarantine", "confirmed_phishing"}
    if request.analyst_override.lower() not in allowed:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"analyst_override must be one of: {allowed}",
        )
    success = update_triage_record(
        analysis_id=request.analysis_id,
        analyst_override=request.analyst_override.lower(),
        analyst_note=request.analyst_note,
    )
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No triage record found for analysis_id: {request.analysis_id}",
        )
    return {"status": "updated", "analysis_id": request.analysis_id}


@router.get(
    "/triage-stats",
    summary="Aggregate triage statistics",
    tags=["Triage"],
)
def triage_stats() -> Dict[str, Any]:
    """Returns aggregate statistics across all triage records."""
    return get_triage_stats()
