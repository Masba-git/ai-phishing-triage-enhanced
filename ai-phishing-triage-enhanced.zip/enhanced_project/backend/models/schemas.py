"""
Pydantic schemas for request/response validation across the API.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Email analysis request
# ---------------------------------------------------------------------------

class AnalyzeRequest(BaseModel):
    raw_email: str = Field(..., description="Raw email text (RFC 5322 or pasted body)")
    filename: Optional[str] = Field(None, description="Original filename if uploaded")
    analyst_note: Optional[str] = Field(None, description="Optional analyst comment")


# ---------------------------------------------------------------------------
# Feature sub-models (returned in analysis result)
# ---------------------------------------------------------------------------

class HeaderFeatures(BaseModel):
    from_address: Optional[str]
    reply_to: Optional[str]
    return_path: Optional[str]
    subject: Optional[str]
    date: Optional[str]
    message_id: Optional[str]
    mailer: Optional[str]
    spf_result: Optional[str]
    dkim_result: Optional[str]
    dmarc_result: Optional[str]
    from_reply_to_mismatch: bool
    return_path_mismatch: bool
    display_name_spoofing: bool
    suspicious_relay: bool


class BodyFeatures(BaseModel):
    plain_text: Optional[str]
    html_present: bool
    char_count: int
    word_count: int
    urgency_score: float          # 0–1
    credential_bait_score: float  # 0–1
    financial_bait_score: float   # 0–1
    social_engineering_score: float
    suspicious_keywords: List[str]


class URLFeatures(BaseModel):
    urls_found: List[str]
    ip_based_urls: List[str]
    shortener_urls: List[str]
    suspicious_tlds: List[str]
    punycode_domains: List[str]
    http_only_urls: List[str]
    excessive_subdomain_urls: List[str]
    anchor_mismatch_urls: List[str]
    brand_impersonation_urls: List[str]
    total_urls: int
    phishing_url_count: int


class AttachmentFeatures(BaseModel):
    attachments: List[Dict[str, Any]]
    dangerous_extension_count: int
    macro_enabled_count: int
    archive_count: int
    executable_count: int
    has_dangerous_attachment: bool


class SenderFeatures(BaseModel):
    sender_domain: Optional[str]
    domain_age_heuristic: str     # "new", "unknown", "established"
    typosquatting_score: float    # 0–1
    domain_similarity_targets: List[str]
    free_email_provider: bool
    domain_mismatch_score: float


# ---------------------------------------------------------------------------
# Main analysis result
# ---------------------------------------------------------------------------

class AnalysisResult(BaseModel):
    analysis_id: str
    timestamp: str
    filename: Optional[str]

    # Parsed email metadata
    headers: HeaderFeatures
    body: BodyFeatures
    urls: URLFeatures
    attachments: AttachmentFeatures
    sender: SenderFeatures

    # ML output
    risk_score: float             # 0.0–1.0
    risk_percent: int             # 0–100
    verdict: str                  # Safe / Review / Suspicious / Quarantine / Confirmed Phishing
    confidence: float             # Model confidence

    # Explainability
    top_indicators: List[str]     # Human-readable reasons
    ml_feature_importance: Dict[str, float]

    # Triage
    triage_status: str
    analyst_note: Optional[str]

    # Attack Type Classification (NEW FEATURE)
    attack_type_results: Optional[Dict] = None
    detected_attacks: Optional[List[str]] = None


# ---------------------------------------------------------------------------
# Triage history
# ---------------------------------------------------------------------------

class TriageRecord(BaseModel):
    record_id: str
    analysis_id: str
    timestamp: str
    subject: Optional[str]
    sender: Optional[str]
    verdict: str
    risk_score: float
    triage_status: str
    analyst_note: Optional[str]
    analyst_override: Optional[str]


class TriageUpdateRequest(BaseModel):
    analysis_id: str
    analyst_override: str
    analyst_note: Optional[str] = None


# ---------------------------------------------------------------------------
# Batch analysis
# ---------------------------------------------------------------------------

class BatchAnalyzeRequest(BaseModel):
    emails: List[AnalyzeRequest]


class BatchAnalyzeResponse(BaseModel):
    total: int
    results: List[AnalysisResult]


# ---------------------------------------------------------------------------
# Model info
# ---------------------------------------------------------------------------

class ModelInfo(BaseModel):
    model_type: str
    version: str
    trained_at: Optional[str]
    accuracy: Optional[float]
    precision: Optional[float]
    recall: Optional[float]
    f1_score: Optional[float]
    feature_count: int
    training_samples: Optional[int]


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

class HealthResponse(BaseModel):
    status: str
    model_loaded: bool
    version: str
    timestamp: str
