"""
Email parsing service.

Parses raw RFC-5322 email text (or .eml content) into structured
components: headers, body, URLs, attachments, metadata.
Designed to handle malformed or partial emails gracefully.
"""
from __future__ import annotations

import email
import email.policy
import re
import quopri
import base64
from email import message_from_string
from email.header import decode_header
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse

from utils.logger import logger


# ---------------------------------------------------------------------------
# Known URL shorteners
# ---------------------------------------------------------------------------
SHORTENER_DOMAINS = {
    "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd",
    "buff.ly", "rebrand.ly", "short.link", "cutt.ly", "shorturl.at",
    "clck.ru", "tiny.cc", "tr.im", "snip.ly", "bl.ink",
}

DANGEROUS_EXTENSIONS = {
    ".exe", ".bat", ".cmd", ".com", ".pif", ".scr", ".vbs", ".vbe",
    ".js", ".jse", ".wsf", ".wsh", ".msi", ".msp", ".mst", ".ps1",
    ".ps2", ".reg", ".lnk", ".jar", ".hta", ".cpl", ".inf",
    # Macro-enabled Office
    ".docm", ".xlsm", ".pptm", ".dotm", ".xltm", ".potm",
    # Archives (may contain payload)
    ".zip", ".rar", ".7z", ".tar", ".gz", ".iso", ".img",
    # PDFs can carry exploits but less dangerous — flagged separately
    ".pdf",
}

MACRO_EXTENSIONS = {".docm", ".xlsm", ".pptm", ".dotm", ".xltm", ".potm"}
ARCHIVE_EXTENSIONS = {".zip", ".rar", ".7z", ".tar", ".gz", ".iso", ".img"}
EXECUTABLE_EXTENSIONS = {
    ".exe", ".bat", ".cmd", ".com", ".pif", ".scr", ".vbs",
    ".js", ".ps1", ".hta", ".jar",
}

FREE_EMAIL_PROVIDERS = {
    "gmail.com", "yahoo.com", "hotmail.com", "outlook.com", "aol.com",
    "icloud.com", "protonmail.com", "mail.com", "zoho.com", "yandex.com",
    "gmx.com", "live.com", "msn.com", "me.com", "inbox.com",
}

BRAND_KEYWORDS = [
    "paypal", "amazon", "apple", "microsoft", "google", "facebook",
    "netflix", "instagram", "twitter", "linkedin", "dropbox", "ebay",
    "wellsfargo", "bankofamerica", "chase", "citibank", "hsbc",
    "fedex", "ups", "dhl", "usps", "irs", "ssa", "docusign",
]

SUSPICIOUS_TLDS = {
    ".xyz", ".top", ".tk", ".gq", ".ml", ".ga", ".cf", ".pw",
    ".click", ".link", ".online", ".site", ".club", ".info",
    ".bid", ".win", ".download", ".stream", ".review", ".science",
}


class ParsedEmail:
    """Container for all parsed email components."""

    def __init__(self) -> None:
        self.subject: Optional[str] = None
        self.from_address: Optional[str] = None
        self.from_name: Optional[str] = None
        self.to_addresses: List[str] = []
        self.reply_to: Optional[str] = None
        self.return_path: Optional[str] = None
        self.date: Optional[str] = None
        self.message_id: Optional[str] = None
        self.mailer: Optional[str] = None
        self.received_chain: List[str] = []
        self.spf_result: Optional[str] = None
        self.dkim_result: Optional[str] = None
        self.dmarc_result: Optional[str] = None
        self.plain_body: Optional[str] = None
        self.html_body: Optional[str] = None
        self.urls: List[str] = []
        self.anchor_map: Dict[str, str] = {}  # anchor_text -> href
        self.attachments: List[Dict[str, Any]] = []
        self.raw_headers: Dict[str, str] = {}


def _decode_header_value(raw_value: Optional[str]) -> Optional[str]:
    """Safely decode a potentially RFC-2047-encoded header value."""
    if raw_value is None:
        return None
    try:
        parts = decode_header(raw_value)
        decoded_parts = []
        for part, charset in parts:
            if isinstance(part, bytes):
                charset = charset or "utf-8"
                try:
                    decoded_parts.append(part.decode(charset, errors="replace"))
                except (LookupError, UnicodeDecodeError):
                    decoded_parts.append(part.decode("latin-1", errors="replace"))
            else:
                decoded_parts.append(str(part))
        return " ".join(decoded_parts).strip()
    except Exception:
        return str(raw_value)


def _extract_email_address(raw: Optional[str]) -> Optional[str]:
    """Extract bare email address from a display-name <addr> format."""
    if not raw:
        return None
    match = re.search(r"<([^>]+)>", raw)
    if match:
        return match.group(1).strip().lower()
    # Maybe it's already a bare address
    raw = raw.strip().lower()
    if "@" in raw:
        return raw
    return None


def _extract_display_name(raw: Optional[str]) -> Optional[str]:
    """Extract display name from 'Name <email>' format."""
    if not raw:
        return None
    match = re.match(r'^"?([^"<]+)"?\s*<', raw)
    if match:
        return match.group(1).strip()
    return None


def _extract_domain(email_addr: Optional[str]) -> Optional[str]:
    """Return domain portion of an email address."""
    if not email_addr or "@" not in email_addr:
        return None
    return email_addr.split("@", 1)[1].lower()


def _extract_urls_from_text(text: str) -> List[str]:
    """Extract all HTTP/HTTPS URLs from plain text."""
    pattern = re.compile(
        r'https?://[^\s<>"\')\]]+',
        re.IGNORECASE,
    )
    raw = pattern.findall(text)
    # Deduplicate while preserving order
    seen: set = set()
    result = []
    for url in raw:
        url = url.rstrip(".,;:!?)")
        if url not in seen:
            seen.add(url)
            result.append(url)
    return result


def _extract_urls_from_html(html: str) -> Tuple[List[str], Dict[str, str]]:
    """
    Extract hrefs and anchor text from HTML.
    Returns (url_list, anchor_text_to_url mapping).
    """
    urls: List[str] = []
    anchor_map: Dict[str, str] = {}
    seen: set = set()

    href_pattern = re.compile(r'href=["\']([^"\']+)["\']', re.IGNORECASE)
    anchor_pattern = re.compile(r'<a[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', re.IGNORECASE | re.DOTALL)

    # Anchor map: anchor text -> href
    for match in anchor_pattern.finditer(html):
        href = match.group(1).strip()
        inner = re.sub(r"<[^>]+>", "", match.group(2)).strip()
        if href.startswith("http"):
            if href not in seen:
                seen.add(href)
                urls.append(href)
            if inner:
                anchor_map[inner] = href

    # Also grab any raw hrefs
    for match in href_pattern.finditer(html):
        href = match.group(1).strip()
        if href.startswith("http") and href not in seen:
            seen.add(href)
            urls.append(href)

    return urls, anchor_map


def _parse_authentication_results(headers: Dict[str, str]) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    """Parse Authentication-Results header for SPF/DKIM/DMARC."""
    auth_header = headers.get("authentication-results", "")
    if not auth_header:
        return None, None, None

    spf = dkim = dmarc = None

    spf_match = re.search(r"spf=(pass|fail|softfail|neutral|none|permerror|temperror)", auth_header, re.IGNORECASE)
    if spf_match:
        spf = spf_match.group(1).lower()

    dkim_match = re.search(r"dkim=(pass|fail|none|permerror|temperror)", auth_header, re.IGNORECASE)
    if dkim_match:
        dkim = dkim_match.group(1).lower()

    dmarc_match = re.search(r"dmarc=(pass|fail|none|bestguesspass)", auth_header, re.IGNORECASE)
    if dmarc_match:
        dmarc = dmarc_match.group(1).lower()

    return spf, dkim, dmarc


def _decode_part_payload(part: email.message.Message) -> str:
    """Safely decode a MIME part's payload to string."""
    payload = part.get_payload(decode=True)
    if payload is None:
        return ""
    charset = part.get_content_charset() or "utf-8"
    try:
        return payload.decode(charset, errors="replace")
    except (LookupError, UnicodeDecodeError):
        return payload.decode("latin-1", errors="replace")


def parse_email(raw_email: str) -> ParsedEmail:
    """
    Parse raw email string into a ParsedEmail object.

    Handles:
    - Plain text emails
    - Multipart MIME emails
    - HTML-only emails
    - Malformed/partial emails
    - RFC-2047 encoded headers
    """
    result = ParsedEmail()

    try:
        msg = message_from_string(raw_email, policy=email.policy.compat32)
    except Exception as exc:
        logger.warning(f"Email parse error: {exc}. Attempting fallback parse.")
        try:
            msg = message_from_string(raw_email)
        except Exception:
            logger.error("Total email parse failure — returning empty ParsedEmail.")
            return result

    # -----------------------------------------------------------------------
    # Headers
    # -----------------------------------------------------------------------
    for key in msg.keys():
        result.raw_headers[key.lower()] = str(msg[key])

    result.subject = _decode_header_value(msg.get("subject"))
    result.from_address = _extract_email_address(_decode_header_value(msg.get("from")))
    result.from_name = _extract_display_name(_decode_header_value(msg.get("from")))
    result.reply_to = _extract_email_address(_decode_header_value(msg.get("reply-to")))
    result.return_path = _extract_email_address(_decode_header_value(msg.get("return-path")))
    result.date = _decode_header_value(msg.get("date"))
    result.message_id = _decode_header_value(msg.get("message-id"))
    result.mailer = _decode_header_value(msg.get("x-mailer") or msg.get("user-agent"))

    # Received chain
    result.received_chain = [str(r) for r in msg.get_all("received", [])]

    # To addresses
    to_raw = _decode_header_value(msg.get("to")) or ""
    result.to_addresses = [
        addr.strip() for addr in to_raw.split(",") if "@" in addr
    ]

    # SPF / DKIM / DMARC
    spf, dkim, dmarc = _parse_authentication_results(result.raw_headers)
    result.spf_result = spf
    result.dkim_result = dkim
    result.dmarc_result = dmarc

    # -----------------------------------------------------------------------
    # Body — walk MIME tree
    # -----------------------------------------------------------------------
    plain_parts: List[str] = []
    html_parts: List[str] = []

    if msg.is_multipart():
        for part in msg.walk():
            content_type = part.get_content_type()
            content_disposition = str(part.get("content-disposition", "")).lower()

            if "attachment" in content_disposition or part.get_filename():
                # Attachment
                filename = _decode_header_value(part.get_filename()) or "unknown"
                mime_type = content_type
                size = len(part.get_payload(decode=True) or b"")
                result.attachments.append({
                    "filename": filename,
                    "mime_type": mime_type,
                    "size_bytes": size,
                })
            elif content_type == "text/plain":
                plain_parts.append(_decode_part_payload(part))
            elif content_type == "text/html":
                html_parts.append(_decode_part_payload(part))
    else:
        content_type = msg.get_content_type()
        if content_type == "text/html":
            html_parts.append(_decode_part_payload(msg))
        else:
            plain_parts.append(_decode_part_payload(msg))

    result.plain_body = "\n".join(plain_parts).strip() if plain_parts else None
    result.html_body = "\n".join(html_parts).strip() if html_parts else None

    # -----------------------------------------------------------------------
    # URL extraction
    # -----------------------------------------------------------------------
    all_urls: List[str] = []

    if result.plain_body:
        all_urls.extend(_extract_urls_from_text(result.plain_body))

    if result.html_body:
        html_urls, anchor_map = _extract_urls_from_html(result.html_body)
        result.anchor_map = anchor_map
        # Add html URLs not already captured
        existing = set(all_urls)
        for u in html_urls:
            if u not in existing:
                all_urls.append(u)
                existing.add(u)

    result.urls = all_urls

    logger.debug(
        f"Parsed email: subject='{result.subject}', from='{result.from_address}', "
        f"urls={len(result.urls)}, attachments={len(result.attachments)}"
    )
    return result


def analyze_urls(urls: List[str], anchor_map: Dict[str, str]) -> Dict[str, Any]:
    """
    Analyze extracted URLs for phishing indicators.
    Returns structured URL feature dict.
    """
    ip_based: List[str] = []
    shortener: List[str] = []
    suspicious_tld: List[str] = []
    punycode: List[str] = []
    http_only: List[str] = []
    excessive_subdomains: List[str] = []
    brand_impersonation: List[str] = []
    anchor_mismatch: List[str] = []

    ip_pattern = re.compile(r"https?://(\d{1,3}\.){3}\d{1,3}")

    for url in urls:
        try:
            parsed = urlparse(url)
            hostname = (parsed.hostname or "").lower()

            # IP-based URL
            if ip_pattern.match(url):
                ip_based.append(url)

            # Shortener
            if any(hostname == s or hostname.endswith("." + s) for s in SHORTENER_DOMAINS):
                shortener.append(url)

            # Suspicious TLD
            domain_parts = hostname.split(".")
            if domain_parts:
                tld = "." + domain_parts[-1]
                if tld in SUSPICIOUS_TLDS:
                    suspicious_tld.append(url)

            # Punycode (IDN homograph)
            if "xn--" in hostname:
                punycode.append(url)

            # HTTP-only (no TLS)
            if parsed.scheme == "http":
                http_only.append(url)

            # Excessive subdomains (more than 3 levels)
            if len(domain_parts) > 4:
                excessive_subdomains.append(url)

            # Brand impersonation
            for brand in BRAND_KEYWORDS:
                if brand in hostname and not hostname.endswith(f"{brand}.com"):
                    brand_impersonation.append(url)
                    break

        except Exception:
            pass

    # Anchor text mismatch — visible text says one domain, href goes to another
    for anchor_text, href in anchor_map.items():
        text_lower = anchor_text.lower()
        try:
            href_domain = urlparse(href).hostname or ""
        except Exception:
            continue
        # If anchor text looks like a URL / domain and doesn't match href domain
        if re.search(r"\b\w+\.\w{2,}\b", text_lower):
            text_domain_match = re.search(r"\b([\w-]+\.\w{2,})\b", text_lower)
            if text_domain_match:
                text_domain = text_domain_match.group(1).lower()
                if text_domain not in href_domain and href_domain not in text_domain:
                    anchor_mismatch.append(href)

    phishing_count = len(set(
        ip_based + shortener + suspicious_tld + punycode +
        http_only + excessive_subdomains + brand_impersonation + anchor_mismatch
    ))

    return {
        "urls_found": urls,
        "ip_based_urls": list(set(ip_based)),
        "shortener_urls": list(set(shortener)),
        "suspicious_tlds": list(set(suspicious_tld)),
        "punycode_domains": list(set(punycode)),
        "http_only_urls": list(set(http_only)),
        "excessive_subdomain_urls": list(set(excessive_subdomains)),
        "brand_impersonation_urls": list(set(brand_impersonation)),
        "anchor_mismatch_urls": list(set(anchor_mismatch)),
        "total_urls": len(urls),
        "phishing_url_count": phishing_count,
    }


def analyze_attachments(attachments: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Analyze attachment list for dangerous file types."""
    dangerous_ext_count = 0
    macro_count = 0
    archive_count = 0
    exe_count = 0

    for att in attachments:
        fname = att.get("filename", "").lower()
        ext = "." + fname.rsplit(".", 1)[-1] if "." in fname else ""

        if ext in DANGEROUS_EXTENSIONS:
            dangerous_ext_count += 1
        if ext in MACRO_EXTENSIONS:
            macro_count += 1
        if ext in ARCHIVE_EXTENSIONS:
            archive_count += 1
        if ext in EXECUTABLE_EXTENSIONS:
            exe_count += 1

    return {
        "attachments": attachments,
        "dangerous_extension_count": dangerous_ext_count,
        "macro_enabled_count": macro_count,
        "archive_count": archive_count,
        "executable_count": exe_count,
        "has_dangerous_attachment": dangerous_ext_count > 0,
    }


def analyze_sender(from_address: Optional[str]) -> Dict[str, Any]:
    """Heuristic sender reputation analysis."""
    import difflib

    domain = _extract_domain(from_address) if from_address else None

    free_email = domain in FREE_EMAIL_PROVIDERS if domain else False

    typo_score = 0.0
    similarity_targets: List[str] = []
    trusted_domains = ["paypal.com", "amazon.com", "apple.com", "microsoft.com",
                       "google.com", "facebook.com", "irs.gov", "chase.com",
                       "wellsfargo.com", "netflix.com"]

    if domain:
        for trusted in trusted_domains:
            ratio = difflib.SequenceMatcher(None, domain, trusted).ratio()
            if 0.6 < ratio < 1.0:  # Similar but not identical
                typo_score = max(typo_score, ratio)
                similarity_targets.append(trusted)

    # Domain age heuristic — we can't do live DNS, but flag very short domains
    domain_age_heuristic = "unknown"
    if domain:
        parts = domain.split(".")
        # Heuristic: very short second-level domain might be newly registered
        if len(parts) >= 2 and len(parts[-2]) <= 4:
            domain_age_heuristic = "new"
        else:
            domain_age_heuristic = "established"

    # Domain mismatch score (rough)
    mismatch_score = min(typo_score, 0.99)

    return {
        "sender_domain": domain,
        "domain_age_heuristic": domain_age_heuristic,
        "typosquatting_score": round(typo_score, 3),
        "domain_similarity_targets": similarity_targets,
        "free_email_provider": free_email,
        "domain_mismatch_score": round(mismatch_score, 3),
    }
