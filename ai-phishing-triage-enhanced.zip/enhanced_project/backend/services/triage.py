"""
Triage service.

Assigns triage status from risk score, manages local JSON history via TinyDB,
and supports analyst overrides.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from tinydb import TinyDB, Query
from tinydb.storages import JSONStorage
from tinydb.middlewares import CachingMiddleware

from utils.config import settings
from utils.logger import logger


# ---------------------------------------------------------------------------
# Verdict / status thresholds
# ---------------------------------------------------------------------------

def score_to_verdict(risk_score: float) -> str:
    """Map risk score to a human-readable verdict label."""
    if risk_score >= settings.risk_threshold_quarantine:
        return "Confirmed Phishing"
    elif risk_score >= settings.risk_threshold_suspicious:
        return "Quarantine"
    elif risk_score >= settings.risk_threshold_review:
        return "Suspicious"
    elif risk_score >= settings.risk_threshold_safe:
        return "Review"
    else:
        return "Safe"


def score_to_triage_status(risk_score: float) -> str:
    """Map risk score to triage workflow status."""
    if risk_score >= settings.risk_threshold_quarantine:
        return "quarantine"
    elif risk_score >= settings.risk_threshold_suspicious:
        return "suspicious"
    elif risk_score >= settings.risk_threshold_review:
        return "review"
    else:
        return "safe"


# ---------------------------------------------------------------------------
# TinyDB setup
# ---------------------------------------------------------------------------

def _get_db() -> TinyDB:
    """Get or create TinyDB instance with caching middleware."""
    import pathlib
    pathlib.Path(settings.triage_db_path).parent.mkdir(parents=True, exist_ok=True)
    return TinyDB(
        settings.triage_db_path,
        storage=CachingMiddleware(JSONStorage),
        sort_keys=True,
        indent=2,
    )


# ---------------------------------------------------------------------------
# Triage history CRUD
# ---------------------------------------------------------------------------

def save_triage_record(
    analysis_id: str,
    subject: Optional[str],
    sender: Optional[str],
    verdict: str,
    risk_score: float,
    triage_status: str,
    analyst_note: Optional[str] = None,
) -> str:
    """Persist a triage record and return its record_id."""
    record_id = str(uuid.uuid4())
    record = {
        "record_id": record_id,
        "analysis_id": analysis_id,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "subject": subject,
        "sender": sender,
        "verdict": verdict,
        "risk_score": risk_score,
        "triage_status": triage_status,
        "analyst_note": analyst_note,
        "analyst_override": None,
    }
    try:
        db = _get_db()
        db.insert(record)
        db.storage.flush()
        logger.info(f"Triage record saved: {record_id} | verdict={verdict} | score={risk_score:.3f}")
    except Exception as exc:
        logger.error(f"Failed to save triage record: {exc}")
    return record_id


def get_triage_history(limit: int = 100) -> List[Dict[str, Any]]:
    """Return triage history sorted by timestamp descending."""
    try:
        db = _get_db()
        all_records = db.all()
        sorted_records = sorted(
            all_records,
            key=lambda r: r.get("timestamp", ""),
            reverse=True,
        )
        return sorted_records[:limit]
    except Exception as exc:
        logger.error(f"Failed to retrieve triage history: {exc}")
        return []


def update_triage_record(
    analysis_id: str,
    analyst_override: str,
    analyst_note: Optional[str] = None,
) -> bool:
    """Update analyst override on an existing record by analysis_id."""
    try:
        db = _get_db()
        TriageQuery = Query()
        update_data: Dict[str, Any] = {"analyst_override": analyst_override}
        if analyst_note is not None:
            update_data["analyst_note"] = analyst_note
        updated = db.update(update_data, TriageQuery.analysis_id == analysis_id)
        db.storage.flush()
        if updated:
            logger.info(f"Triage override applied to analysis_id={analysis_id}: {analyst_override}")
            return True
        else:
            logger.warning(f"No triage record found for analysis_id={analysis_id}")
            return False
    except Exception as exc:
        logger.error(f"Failed to update triage record: {exc}")
        return False


def get_triage_stats() -> Dict[str, Any]:
    """Compute aggregate statistics over all triage records."""
    try:
        db = _get_db()
        records = db.all()
        if not records:
            return {
                "total": 0,
                "safe": 0,
                "review": 0,
                "suspicious": 0,
                "quarantine": 0,
                "confirmed_phishing": 0,
                "avg_risk_score": 0.0,
                "phishing_rate": 0.0,
            }

        verdict_counts: Dict[str, int] = {
            "Safe": 0, "Review": 0, "Suspicious": 0,
            "Quarantine": 0, "Confirmed Phishing": 0,
        }
        scores = []
        for r in records:
            v = r.get("verdict", "Unknown")
            if v in verdict_counts:
                verdict_counts[v] += 1
            score = r.get("risk_score", 0.0)
            if isinstance(score, (int, float)):
                scores.append(float(score))

        total = len(records)
        avg_score = sum(scores) / len(scores) if scores else 0.0
        phishing = verdict_counts.get("Confirmed Phishing", 0) + verdict_counts.get("Quarantine", 0)

        return {
            "total": total,
            "safe": verdict_counts["Safe"],
            "review": verdict_counts["Review"],
            "suspicious": verdict_counts["Suspicious"],
            "quarantine": verdict_counts["Quarantine"],
            "confirmed_phishing": verdict_counts["Confirmed Phishing"],
            "avg_risk_score": round(avg_score, 4),
            "phishing_rate": round(phishing / total, 4) if total > 0 else 0.0,
        }
    except Exception as exc:
        logger.error(f"Failed to compute triage stats: {exc}")
        return {}
