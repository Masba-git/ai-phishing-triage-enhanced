"""
ATTACK TYPE CLASSIFIER
======================

Multi-label classification module for identifying types of phishing attacks.
This is a NEW, modular component that does NOT modify existing phishing detection.

It takes:
  - Existing extracted features
  - Parsed email data

It outputs:
  - Multi-label attack type probabilities
  - Confidence scores for each attack type
  - Human-readable classification results

Author: Masba Ur Rahaman
Date: 2024
"""

from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from utils.logger import logger


@dataclass
class AttackTypeResult:
    """Data class for individual attack type classification"""
    attack_type: str
    confidence: float
    detected: bool
    indicators: List[str]


class AttackTypeClassifier:
    """
    Multi-label classifier for phishing attack types.
    
    Uses heuristic scoring based on:
    - Extracted features (reuses existing 32 features)
    - Email content patterns
    - Risk indicators
    
    NO CHANGES to existing 32-feature system or ML model.
    Reuses existing extracted data.
    """
    
    # Attack type categories
    ATTACK_TYPES = {
        "credential_theft": "Credential Theft / Credential Harvesting",
        "brand_impersonation": "Brand Impersonation",
        "financial_fraud": "Financial / Invoice Fraud",
        "malware_delivery": "Malware Delivery",
        "qr_phishing": "QR Phishing / Quishing",
        "account_takeover": "Account Takeover",
        "bec": "Business Email Compromise (BEC)",
        "social_engineering": "Generic Social Engineering"
    }
    
    def __init__(self):
        """Initialize the attack type classifier"""
        self.attack_type_rules = self._define_attack_rules()
        logger.info("AttackTypeClassifier initialized with 8 attack types")
    
    def _define_attack_rules(self) -> Dict:
        """
        Define heuristic rules for each attack type.
        
        These rules use EXISTING features without duplicating extraction.
        """
        
        return {
            "credential_theft": {
                "feature_weights": {
                    "credential_bait_score": 0.35,
                    "urgency_score": 0.15,
                    "from_reply_to_mismatch": 0.15,
                    "html_present": 0.10,
                    "word_count": 0.05,
                    "suspicious_keywords_count": 0.10,
                    "total_urls": 0.10
                },
                "min_threshold": 0.40,
            },
            
            "brand_impersonation": {
                "feature_weights": {
                    "display_name_spoofing": 0.30,
                    "typosquatting_score": 0.25,
                    "suspicious_tlds_count": 0.15,
                    "from_reply_to_mismatch": 0.15,
                    "punycode_domains_count": 0.10,
                    "brand_impersonation_urls_count": 0.05
                },
                "min_threshold": 0.35,
            },
            
            "financial_fraud": {
                "feature_weights": {
                    "financial_bait_score": 0.40,
                    "urgency_score": 0.20,
                    "credential_bait_score": 0.15,
                    "suspicious_keywords_count": 0.10,
                    "dangerous_attachment_count": 0.10,
                    "html_present": 0.05
                },
                "min_threshold": 0.35,
            },
            
            "malware_delivery": {
                "feature_weights": {
                    "dangerous_extension_count": 0.40,
                    "archive_count": 0.25,
                    "total_urls": 0.15,
                    "ip_based_urls_count": 0.10,
                    "http_only_urls_count": 0.05,
                    "urgency_score": 0.05
                },
                "min_threshold": 0.30,
            },
            
            "qr_phishing": {
                "feature_weights": {
                    "has_qr_code": 0.50,
                    "total_urls": 0.15,
                    "html_present": 0.15,
                    "urgency_score": 0.10,
                    "suspicious_keywords_count": 0.10
                },
                "min_threshold": 0.40,
            },
            
            "account_takeover": {
                "feature_weights": {
                    "credential_bait_score": 0.35,
                    "from_reply_to_mismatch": 0.20,
                    "urgency_score": 0.20,
                    "html_present": 0.10,
                    "dkim_fail": 0.10,
                    "word_count": 0.05
                },
                "min_threshold": 0.40,
            },
            
            "bec": {
                "feature_weights": {
                    "display_name_spoofing": 0.25,
                    "typosquatting_score": 0.20,
                    "financial_bait_score": 0.25,
                    "from_reply_to_mismatch": 0.15,
                    "urgency_score": 0.15
                },
                "min_threshold": 0.35,
            },
            
            "social_engineering": {
                "feature_weights": {
                    "social_engineering_score": 0.40,
                    "urgency_score": 0.20,
                    "credential_bait_score": 0.15,
                    "suspicious_keywords_count": 0.15,
                    "html_present": 0.10
                },
                "min_threshold": 0.35,
            }
        }
    
    def classify(self, features: Dict, parsed_email: Dict) -> Dict[str, AttackTypeResult]:
        """
        Classify the email into attack types (multi-label).
        
        Args:
            features: Dictionary of extracted features from feature_extractor.py
            parsed_email: Dictionary with parsed email data (body, subject, etc)
        
        Returns:
            Dictionary mapping attack type keys to AttackTypeResult objects
        """
        
        results = {}
        
        # Detect QR code (the ONLY new feature check beyond existing 32)
        has_qr_code = self._detect_qr_code(
            parsed_email.get('body_html', '') or parsed_email.get('body_text', '')
        )
        
        # Score each attack type
        for attack_key, attack_rule in self.attack_type_rules.items():
            score = self._calculate_attack_score(
                attack_key,
                attack_rule,
                features,
                has_qr_code
            )
            
            confidence = min(max(score, 0.0), 1.0)
            detected = confidence >= attack_rule['min_threshold']
            
            # Get indicators for this attack type
            indicators = self._get_indicators(
                attack_key,
                attack_rule,
                features,
                has_qr_code
            )
            
            attack_type_name = self.ATTACK_TYPES[attack_key]
            results[attack_key] = AttackTypeResult(
                attack_type=attack_type_name,
                confidence=confidence,
                detected=detected,
                indicators=indicators
            )
        
        logger.debug(f"Attack type classification complete - {len([r for r in results.values() if r.detected])} types detected")
        
        return results
    
    def _calculate_attack_score(self, attack_key: str, attack_rule: Dict,
                               features: Dict, has_qr_code: bool) -> float:
        """Calculate confidence score for a single attack type using weighted features."""
        
        score = 0.0
        total_weight = 0.0
        weights = attack_rule['feature_weights']
        
        for feature_name, weight in weights.items():
            # Special: QR code detection
            if feature_name == "has_qr_code":
                if has_qr_code:
                    score += 1.0 * weight
                total_weight += weight
                continue
            
            # Standard feature lookup
            mapped_feature = self._map_feature_name(feature_name, features)
            
            if mapped_feature is not None:
                feature_value = mapped_feature
                
                # Handle different data types
                if isinstance(feature_value, bool):
                    score += (1.0 if feature_value else 0.0) * weight
                elif isinstance(feature_value, (int, float)):
                    if isinstance(feature_value, int):
                        # Count-type feature - normalize
                        normalized = min(feature_value / 5.0, 1.0)
                    else:
                        # Float feature - assume normalized [0,1]
                        normalized = min(feature_value, 1.0)
                    score += normalized * weight
                
                total_weight += weight
        
        # Normalize by total weight
        if total_weight > 0:
            score = score / total_weight
        
        return score
    
    def _map_feature_name(self, feature_name: str, features: Dict) -> Optional:
        """Map heuristic feature names to extracted feature keys."""
        
        mapping = {
            # Body scores
            "credential_bait_score": ("body", "credential_bait_score"),
            "urgency_score": ("body", "urgency_score"),
            "financial_bait_score": ("body", "financial_bait_score"),
            "social_engineering_score": ("body", "social_engineering_score"),
            "html_present": ("body", "html_present"),
            "word_count": ("body", "word_count"),
            "suspicious_keywords_count": ("body", "suspicious_keywords", "count"),
            
            # Header features
            "from_reply_to_mismatch": ("headers", "from_reply_to_mismatch"),
            "display_name_spoofing": ("headers", "display_name_spoofing"),
            "dkim_fail": ("headers", "dkim_result"),
            
            # Sender features
            "typosquatting_score": ("sender", "typosquatting_score"),
            
            # URL features
            "total_urls": ("urls", "total_urls"),
            "ip_based_urls_count": ("urls", "ip_based_urls", "count"),
            "suspicious_tlds_count": ("urls", "suspicious_tlds", "count"),
            "punycode_domains_count": ("urls", "punycode_domains", "count"),
            "http_only_urls_count": ("urls", "http_only_urls", "count"),
            "brand_impersonation_urls_count": ("urls", "brand_impersonation_urls", "count"),
            
            # Attachment features
            "dangerous_extension_count": ("attachments", "dangerous_extension_count"),
            "archive_count": ("attachments", "archive_count"),
        }
        
        if feature_name not in mapping:
            return None
        
        path = mapping[feature_name]
        current = features
        
        for key in path:
            if key == "count":
                return len(current) if isinstance(current, list) else 0
            elif isinstance(current, dict):
                current = current.get(key)
                if current is None:
                    return None
            else:
                return None
        
        return current
    
    def _get_indicators(self, attack_key: str, attack_rule: Dict,
                       features: Dict, has_qr_code: bool) -> List[str]:
        """Get human-readable indicators contributing to this attack classification."""
        
        indicators = []
        weights = attack_rule['feature_weights']
        
        descriptions = {
            "credential_bait_score": "Email contains login/password/account verification requests",
            "urgency_score": "High sense of urgency (deadline, immediate action)",
            "from_reply_to_mismatch": "Reply-To address differs from sender domain",
            "html_present": "Email contains HTML forms or suspicious formatting",
            "word_count": "Short email body (typical for phishing)",
            "suspicious_keywords_count": "Multiple suspicious keywords detected",
            "total_urls": "Multiple links in email",
            "display_name_spoofing": "Sender name doesn't match actual domain",
            "typosquatting_score": "Domain name is misspelled (typosquatting)",
            "suspicious_tlds_count": "Suspicious top-level domain (.xyz, .tk, etc)",
            "punycode_domains_count": "Internationalized domain names (IDN/punycode)",
            "brand_impersonation_urls_count": "URLs contain brand names",
            "financial_bait_score": "Email mentions money/payment/invoice",
            "dangerous_extension_count": "Dangerous executable attachments",
            "archive_count": "Compressed archives (potential malware)",
            "ip_based_urls_count": "Links use IP addresses instead of domains",
            "http_only_urls_count": "Unencrypted HTTP links (no HTTPS)",
            "dkim_fail": "Email signature verification failed",
            "social_engineering_score": "Psychological manipulation techniques detected",
            "has_qr_code": "QR code present in email",
        }
        
        # Collect active indicators
        active = []
        
        for feature_name, weight in weights.items():
            if feature_name == "has_qr_code":
                if has_qr_code:
                    active.append((weight, feature_name))
            elif self._map_feature_name(feature_name, features) is not None:
                value = self._map_feature_name(feature_name, features)
                is_active = False
                
                if isinstance(value, bool):
                    is_active = value
                elif isinstance(value, (int, float)):
                    is_active = value > (0.3 if isinstance(value, float) else 0)
                
                if is_active:
                    active.append((weight, feature_name))
        
        # Sort by importance and get top 5
        active.sort(key=lambda x: x[0], reverse=True)
        
        for weight, feature_name in active[:5]:
            desc = descriptions.get(feature_name, feature_name.replace('_', ' ').title())
            indicators.append(desc)
        
        return indicators
    
    def _detect_qr_code(self, email_body: str) -> bool:
        """Detect QR code presence in email."""
        
        if not email_body:
            return False
        
        body_lower = email_body.lower()
        
        qr_patterns = [
            'qrcode', 'qr code', 'qr_code',
            'barcode', 'bar code', 'scan the qr',
            'scan this qr', 'scan qr code', 'scan the code',
            'scan the barcode', 'please scan'
        ]
        
        for pattern in qr_patterns:
            if pattern in body_lower:
                return True
        
        return False
    
    def get_top_attack_types(self, classification_results: Dict, top_n: int = 8) -> List:
        """Get top N attack types sorted by confidence."""
        
        sorted_attacks = sorted(
            classification_results.items(),
            key=lambda x: x[1].confidence,
            reverse=True
        )
        
        return [
            {
                'key': key,
                'name': result.attack_type,
                'confidence': result.confidence,
                'detected': result.detected
            }
            for key, result in sorted_attacks[:top_n]
        ]
    
    def get_detected_attacks(self, classification_results: Dict) -> List[str]:
        """Get only detected attack types (above threshold)."""
        
        return [
            result.attack_type
            for result in classification_results.values()
            if result.detected
        ]
    
    def format_result_for_display(self, classification_results: Dict) -> Dict:
        """Format results for GUI/API display."""
        
        formatted = {}
        
        for attack_key, result in classification_results.items():
            confidence_pct = result.confidence * 100
            
            if result.detected:
                status = "Detected"
            elif result.confidence > 0.5:
                status = "Suspicious"
            else:
                status = "Low Evidence"
            
            formatted[attack_key] = {
                "name": result.attack_type,
                "confidence": round(confidence_pct, 1),
                "confidence_decimal": round(result.confidence, 3),
                "detected": result.detected,
                "status": status,
                "indicators": result.indicators
            }
        
        return formatted


def get_classifier() -> AttackTypeClassifier:
    """Get or create the singleton classifier instance."""
    global _classifier_instance
    if _classifier_instance is None:
        _classifier_instance = AttackTypeClassifier()
    return _classifier_instance


_classifier_instance = None
