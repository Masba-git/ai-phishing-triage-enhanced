"""
ML inference engine.

Loads trained phishing classification model and produces:
- Phishing probability (risk score)
- Feature importance map

Falls back to rule-based scoring if model is unavailable.
"""
from __future__ import annotations

import json
import pathlib
from typing import Any, Dict, Optional, Tuple

import joblib
import numpy as np

from utils.config import settings
from utils.logger import logger


FEATURE_NAMES = [
    "from_reply_to_mismatch",
    "return_path_mismatch",
    "display_name_spoofing",
    "suspicious_relay",
    "spf_fail",
    "dkim_fail",
    "dmarc_fail",
    "urgency_score",
    "credential_bait_score",
    "financial_bait_score",
    "social_engineering_score",
    "html_present",
    "suspicious_keyword_count",
    "body_word_count",
    "total_urls",
    "ip_based_urls",
    "shortener_urls",
    "suspicious_tlds",
    "punycode_domains",
    "http_only_urls",
    "excessive_subdomain_urls",
    "brand_impersonation_urls",
    "anchor_mismatch_urls",
    "phishing_url_count",
    "has_dangerous_attachment",
    "dangerous_extension_count",
    "macro_enabled_count",
    "archive_count",
    "executable_count",
    "typosquatting_score",
    "free_email_provider",
    "domain_mismatch_score",
]


class InferenceEngine:
    """Wraps trained model and provides predict interface."""

    def __init__(self) -> None:
        self.model = None
        self.model_meta: Dict[str, Any] = {}
        self._loaded = False
        self._load()

    def _load(self) -> None:
        model_path = pathlib.Path(settings.model_path)
        if not model_path.exists():
            logger.warning(
                f"Model file not found at {model_path}. "
                "Run `python scripts/train_model.py` to train the model. "
                "Falling back to rule-based scoring."
            )
            return

        try:
            bundle = joblib.load(model_path)
            self.model = bundle.get("model")
            self.model_meta = bundle.get("meta", {})
            self._loaded = True
            logger.info(
                f"Model loaded: {self.model_meta.get('model_type')} | "
                f"accuracy={self.model_meta.get('accuracy', 'N/A')} | "
                f"trained_at={self.model_meta.get('trained_at', 'N/A')}"
            )
        except Exception as exc:
            logger.error(f"Model load failed: {exc}. Using rule-based fallback.")

    def is_loaded(self) -> bool:
        return self._loaded

    def predict(
        self,
        numeric_features: Dict[str, float],
        rule_score: float,
    ) -> Tuple[float, float, Dict[str, float]]:
        """
        Returns (risk_score, confidence, feature_importance_map).

        If model is available: blends ML probability with rule score.
        If model unavailable: uses rule_score directly.
        """
        feature_vec = np.array(
            [numeric_features.get(f, 0.0) for f in FEATURE_NAMES],
            dtype=np.float32,
        ).reshape(1, -1)

        if self._loaded and self.model is not None:
            try:
                proba = self.model.predict_proba(feature_vec)[0]
                # Class 1 = phishing probability
                ml_score = float(proba[1]) if len(proba) > 1 else float(proba[0])

                # Blend: 70% ML, 30% rule-based
                risk_score = round(0.70 * ml_score + 0.30 * rule_score, 4)
                confidence = round(float(np.max(proba)), 4)

                # Feature importance
                importance_map = self._get_feature_importance(feature_vec)
                return risk_score, confidence, importance_map

            except Exception as exc:
                logger.error(f"Inference error: {exc}. Falling back to rule-based score.")

        # Fallback — rule-based only
        return round(rule_score, 4), round(rule_score, 4), {}

    def _get_feature_importance(self, feature_vec: np.ndarray) -> Dict[str, float]:
        """Return per-feature importance contribution from the model."""
        importance_map: Dict[str, float] = {}
        try:
            if hasattr(self.model, "feature_importances_"):
                importances = self.model.feature_importances_
                for name, imp in zip(FEATURE_NAMES, importances):
                    importance_map[name] = round(float(imp), 5)
            elif hasattr(self.model, "coef_"):
                coefs = np.abs(self.model.coef_[0])
                total = coefs.sum() or 1.0
                for name, coef in zip(FEATURE_NAMES, coefs):
                    importance_map[name] = round(float(coef / total), 5)
        except Exception:
            pass
        return dict(sorted(importance_map.items(), key=lambda x: x[1], reverse=True)[:15])

    def get_model_info(self) -> Dict[str, Any]:
        """Return model metadata for the /model-info endpoint."""
        if not self._loaded:
            return {
                "model_type": "rule-based-fallback",
                "version": "0.0.0",
                "trained_at": None,
                "accuracy": None,
                "precision": None,
                "recall": None,
                "f1_score": None,
                "feature_count": len(FEATURE_NAMES),
                "training_samples": None,
            }
        return {
            "model_type": self.model_meta.get("model_type", "unknown"),
            "version": self.model_meta.get("version", "1.0.0"),
            "trained_at": self.model_meta.get("trained_at"),
            "accuracy": self.model_meta.get("accuracy"),
            "precision": self.model_meta.get("precision"),
            "recall": self.model_meta.get("recall"),
            "f1_score": self.model_meta.get("f1_score"),
            "feature_count": len(FEATURE_NAMES),
            "training_samples": self.model_meta.get("training_samples"),
        }


# Module-level singleton
_engine: Optional[InferenceEngine] = None


def get_engine() -> InferenceEngine:
    global _engine
    if _engine is None:
        _engine = InferenceEngine()
    return _engine


def reload_engine() -> None:
    """Force-reload model (e.g., after retraining)."""
    global _engine
    _engine = InferenceEngine()
