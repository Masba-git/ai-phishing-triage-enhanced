"""
Feature extraction service.

Converts a ParsedEmail into:
1. Structured feature dicts for the API response
2. Numeric feature vectors for ML inference

All linguistic patterns are compiled once at module load for efficiency.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple

from backend.services.email_parser import (
    ParsedEmail, analyze_urls, analyze_attachments, analyze_sender,
    _extract_domain,
)
from utils.logger import logger


# ---------------------------------------------------------------------------
# Compiled regex patterns — body analysis
# ---------------------------------------------------------------------------

URGENCY_PATTERNS = re.compile(
    r"\b(urgent|immediately|action required|verify now|confirm now|"
    r"limited time|expires|account.*suspended|suspended.*account|"
    r"act now|respond within|hours? to|within \d+ (hour|day)|"
    r"your account (has been|will be)|security alert|unusual activity|"
    r"unauthorized (access|sign.?in)|login attempt|we have noticed|"
    r"we detected|important notice|final notice|last warning|"
    r"failure to|will result in|failure.*respond)\b",
    re.IGNORECASE,
)

CREDENTIAL_PATTERNS = re.compile(
    r"\b(verify your (password|identity|email|account)|"
    r"enter your (login|credentials|password|username)|"
    r"update your (password|billing|payment|information)|"
    r"confirm your (identity|account|email|details)|"
    r"reset your password|click.*to.*verify|validate your|"
    r"your.*credentials|re-?enter|sign in to verify|"
    r"provide your|submit your (details|info|credentials)|"
    r"authenticate)\b",
    re.IGNORECASE,
)

FINANCIAL_PATTERNS = re.compile(
    r"\b(payment (required|failed|declined|overdue)|"
    r"invoice (attached|enclosed|#|number)|"
    r"wire transfer|bank (account|transfer|details)|"
    r"refund (pending|available|approved)|"
    r"your (card|account) (has been|was) (charged|billed|debited)|"
    r"outstanding balance|overdue amount|payment due|"
    r"tax (refund|return)|irs|unclaimed funds|lottery|"
    r"million dollar|inheritance|beneficiary|"
    r"click.*pay|pay.*now|billing (information|issue))\b",
    re.IGNORECASE,
)

SOCIAL_ENG_PATTERNS = re.compile(
    r"\b(dear (customer|user|member|client|friend|valued)|"
    r"we are (contacting|reaching out|writing) (you|to inform)|"
    r"on behalf of|your (account|subscription|membership)|"
    r"click (here|the link|below) to|follow (this|the) link|"
    r"open the attachment|see (attached|the attachment)|"
    r"kindly (click|verify|confirm|update|download)|"
    r"please (click|verify|confirm|update|open)|"
    r"do not ignore|this is not spam|legitimate email|"
    r"congratulations|you (have been selected|are a winner|won)|"
    r"your (prize|reward|gift) is waiting|"
    r"call us immediately|contact us now)\b",
    re.IGNORECASE,
)

SUSPICIOUS_KEYWORDS = [
    "verify", "click here", "login", "password", "urgent", "suspend",
    "account", "update", "confirm", "security", "alert", "invoice",
    "payment", "bank", "wire", "transfer", "unusual activity", "limited time",
    "expires", "immediate action", "dear customer", "prize", "winner",
    "congratulations", "claim", "inheritance", "million", "refund",
    "tax", "irs", "free", "offer", "download", "open attachment",
]


def _score_pattern(text: str, pattern: re.Pattern) -> Tuple[float, List[str]]:
    """
    Returns (score 0-1, list_of_matches).
    Score is capped at 1.0 based on match count relative to a saturation point.
    """
    matches = pattern.findall(text)
    # Flatten tuple groups from alternations
    flat = []
    for m in matches:
        if isinstance(m, tuple):
            flat.extend([x for x in m if x])
        else:
            flat.append(m)
    count = len(flat)
    score = min(count / 5.0, 1.0)  # saturates at 5 matches
    return round(score, 3), list(set(flat))[:10]


def extract_body_features(parsed: ParsedEmail) -> Dict[str, Any]:
    """Analyze email body for phishing language patterns."""
    body_text = ""
    if parsed.plain_body:
        body_text += parsed.plain_body
    if parsed.html_body:
        # Strip HTML tags for text analysis
        clean = re.sub(r"<[^>]+>", " ", parsed.html_body)
        body_text += " " + clean

    if not body_text.strip():
        return {
            "plain_text": None,
            "html_present": bool(parsed.html_body),
            "char_count": 0,
            "word_count": 0,
            "urgency_score": 0.0,
            "credential_bait_score": 0.0,
            "financial_bait_score": 0.0,
            "social_engineering_score": 0.0,
            "suspicious_keywords": [],
        }

    urgency_score, _ = _score_pattern(body_text, URGENCY_PATTERNS)
    cred_score, _ = _score_pattern(body_text, CREDENTIAL_PATTERNS)
    fin_score, _ = _score_pattern(body_text, FINANCIAL_PATTERNS)
    soc_score, _ = _score_pattern(body_text, SOCIAL_ENG_PATTERNS)

    # Collect suspicious keywords present in text
    found_keywords = [
        kw for kw in SUSPICIOUS_KEYWORDS
        if re.search(r"\b" + re.escape(kw) + r"\b", body_text, re.IGNORECASE)
    ]

    return {
        "plain_text": parsed.plain_body,
        "html_present": bool(parsed.html_body),
        "char_count": len(body_text),
        "word_count": len(body_text.split()),
        "urgency_score": urgency_score,
        "credential_bait_score": cred_score,
        "financial_bait_score": fin_score,
        "social_engineering_score": soc_score,
        "suspicious_keywords": found_keywords[:20],
    }


def extract_header_features(parsed: ParsedEmail) -> Dict[str, Any]:
    """Analyze headers for spoofing and authentication failures."""
    from_domain = _extract_domain(parsed.from_address) if parsed.from_address else None
    reply_domain = _extract_domain(parsed.reply_to) if parsed.reply_to else None
    return_domain = _extract_domain(parsed.return_path) if parsed.return_path else None

    from_reply_mismatch = bool(
        reply_domain and from_domain and reply_domain != from_domain
    )
    return_path_mismatch = bool(
        return_domain and from_domain and return_domain != from_domain
    )

    # Display-name spoofing: "PayPal Security" from random@spam.xyz
    display_name_spoof = False
    if parsed.from_name and from_domain:
        name_lower = parsed.from_name.lower()
        for brand in ["paypal", "amazon", "apple", "microsoft", "google",
                      "netflix", "facebook", "instagram", "irs", "chase",
                      "wellsfargo", "bank", "security", "support", "service",
                      "alert", "team", "helpdesk", "admin", "noreply"]:
            if brand in name_lower:
                # Sender claims to be a brand but domain doesn't match
                if brand not in (from_domain or ""):
                    display_name_spoof = True
                    break

    # Suspicious relay: too many received hops or unknown relays
    suspicious_relay = len(parsed.received_chain) > 6

    return {
        "from_address": parsed.from_address,
        "reply_to": parsed.reply_to,
        "return_path": parsed.return_path,
        "subject": parsed.subject,
        "date": parsed.date,
        "message_id": parsed.message_id,
        "mailer": parsed.mailer,
        "spf_result": parsed.spf_result,
        "dkim_result": parsed.dkim_result,
        "dmarc_result": parsed.dmarc_result,
        "from_reply_to_mismatch": from_reply_mismatch,
        "return_path_mismatch": return_path_mismatch,
        "display_name_spoofing": display_name_spoof,
        "suspicious_relay": suspicious_relay,
    }


def extract_all_features(parsed: ParsedEmail) -> Dict[str, Any]:
    """
    Extract all feature groups from a ParsedEmail.
    Returns a dict keyed by feature group.
    """
    headers = extract_header_features(parsed)
    body = extract_body_features(parsed)
    url_analysis = analyze_urls(parsed.urls, parsed.anchor_map)
    attachment_analysis = analyze_attachments(parsed.attachments)
    sender_analysis = analyze_sender(parsed.from_address)

    return {
        "headers": headers,
        "body": body,
        "urls": url_analysis,
        "attachments": attachment_analysis,
        "sender": sender_analysis,
    }


# ---------------------------------------------------------------------------
# Numeric feature vector for ML inference
# ---------------------------------------------------------------------------

def build_numeric_feature_vector(features: Dict[str, Any]) -> Dict[str, float]:
    """
    Convert structured feature dict to a flat numeric dict for the ML model.
    This matches the schema in ml/feature_engineering/features.py.
    """
    h = features.get("headers", {})
    b = features.get("body", {})
    u = features.get("urls", {})
    a = features.get("attachments", {})
    s = features.get("sender", {})

    vec: Dict[str, float] = {
        # Header features
        "from_reply_to_mismatch": float(h.get("from_reply_to_mismatch", False)),
        "return_path_mismatch": float(h.get("return_path_mismatch", False)),
        "display_name_spoofing": float(h.get("display_name_spoofing", False)),
        "suspicious_relay": float(h.get("suspicious_relay", False)),
        "spf_fail": float((h.get("spf_result") or "").lower() in ("fail", "softfail")),
        "dkim_fail": float((h.get("dkim_result") or "").lower() == "fail"),
        "dmarc_fail": float((h.get("dmarc_result") or "").lower() == "fail"),

        # Body features
        "urgency_score": float(b.get("urgency_score", 0.0)),
        "credential_bait_score": float(b.get("credential_bait_score", 0.0)),
        "financial_bait_score": float(b.get("financial_bait_score", 0.0)),
        "social_engineering_score": float(b.get("social_engineering_score", 0.0)),
        "html_present": float(b.get("html_present", False)),
        "suspicious_keyword_count": float(len(b.get("suspicious_keywords", []))),
        "body_word_count": float(min(b.get("word_count", 0), 1000) / 1000.0),

        # URL features
        "total_urls": float(min(u.get("total_urls", 0), 20) / 20.0),
        "ip_based_urls": float(min(len(u.get("ip_based_urls", [])), 5) / 5.0),
        "shortener_urls": float(min(len(u.get("shortener_urls", [])), 5) / 5.0),
        "suspicious_tlds": float(min(len(u.get("suspicious_tlds", [])), 5) / 5.0),
        "punycode_domains": float(min(len(u.get("punycode_domains", [])), 5) / 5.0),
        "http_only_urls": float(min(len(u.get("http_only_urls", [])), 10) / 10.0),
        "excessive_subdomain_urls": float(min(len(u.get("excessive_subdomain_urls", [])), 5) / 5.0),
        "brand_impersonation_urls": float(min(len(u.get("brand_impersonation_urls", [])), 5) / 5.0),
        "anchor_mismatch_urls": float(min(len(u.get("anchor_mismatch_urls", [])), 5) / 5.0),
        "phishing_url_count": float(min(u.get("phishing_url_count", 0), 10) / 10.0),

        # Attachment features
        "has_dangerous_attachment": float(a.get("has_dangerous_attachment", False)),
        "dangerous_extension_count": float(min(a.get("dangerous_extension_count", 0), 5) / 5.0),
        "macro_enabled_count": float(min(a.get("macro_enabled_count", 0), 3) / 3.0),
        "archive_count": float(min(a.get("archive_count", 0), 3) / 3.0),
        "executable_count": float(min(a.get("executable_count", 0), 3) / 3.0),

        # Sender features
        "typosquatting_score": float(s.get("typosquatting_score", 0.0)),
        "free_email_provider": float(s.get("free_email_provider", False)),
        "domain_mismatch_score": float(s.get("domain_mismatch_score", 0.0)),
    }

    return vec
