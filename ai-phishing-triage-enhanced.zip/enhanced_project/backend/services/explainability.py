"""
Explainability engine.

Generates analyst-friendly, specific explanations for phishing indicators.
Every explanation is derived from actual extracted features — no generic messages.
"""
from __future__ import annotations

from typing import Any, Dict, List, Tuple


# ---------------------------------------------------------------------------
# Indicator rules — each rule is (condition_fn, severity_weight, message)
# ---------------------------------------------------------------------------

def _header_indicators(h: Dict[str, Any], s: Dict[str, Any]) -> List[Tuple[float, str]]:
    results = []

    if h.get("from_reply_to_mismatch"):
        results.append((0.75, "Reply-To domain differs from sender domain — classic redirection tactic"))

    if h.get("return_path_mismatch"):
        results.append((0.65, "Return-Path domain does not match From address — bounce-back misdirection"))

    if h.get("display_name_spoofing"):
        results.append((0.80, "Display name impersonates a trusted brand while sender domain is unrelated"))

    if h.get("suspicious_relay"):
        results.append((0.50, "Email passed through an unusually high number of mail relays"))

    spf = (h.get("spf_result") or "").lower()
    dkim = (h.get("dkim_result") or "").lower()
    dmarc = (h.get("dmarc_result") or "").lower()

    if spf in ("fail", "softfail"):
        results.append((0.70, f"SPF authentication failed ({spf.upper()}) — sender not authorized by domain"))

    if dkim == "fail":
        results.append((0.70, "DKIM signature verification failed — email content may have been tampered"))

    if dmarc == "fail":
        results.append((0.80, "DMARC policy failed — email does not align with domain authentication policy"))

    if spf is None and dkim is None and dmarc is None:
        results.append((0.30, "No SPF/DKIM/DMARC authentication headers found"))

    if s.get("typosquatting_score", 0) > 0.7:
        targets = s.get("domain_similarity_targets", [])
        target_str = ", ".join(targets[:3]) if targets else "known brands"
        results.append((0.85, f"Sender domain is suspiciously similar to {target_str} — possible typosquatting"))

    if s.get("free_email_provider"):
        results.append((0.30, "Email sent from a free webmail provider — low-cost sender with no domain ownership"))

    return results


def _body_indicators(b: Dict[str, Any]) -> List[Tuple[float, str]]:
    results = []

    urgency = b.get("urgency_score", 0)
    cred = b.get("credential_bait_score", 0)
    fin = b.get("financial_bait_score", 0)
    soc = b.get("social_engineering_score", 0)
    keywords = b.get("suspicious_keywords", [])

    if urgency > 0.4:
        results.append((urgency, "High-urgency language detected — pressure tactics to force hasty action"))
    elif urgency > 0.1:
        results.append((urgency * 0.6, "Moderate urgency language detected in email body"))

    if cred > 0.4:
        results.append((cred, "Credential harvesting language detected — email prompts user to enter login details"))
    elif cred > 0.1:
        results.append((cred * 0.7, "Potential credential phishing language in email body"))

    if fin > 0.4:
        results.append((fin, "Financial bait language detected — payment, invoice or money-transfer lure"))
    elif fin > 0.1:
        results.append((fin * 0.6, "Moderate financial lure language in email body"))

    if soc > 0.4:
        results.append((soc, "Social engineering patterns detected — impersonation and manipulation tactics"))
    elif soc > 0.1:
        results.append((soc * 0.5, "Mild social engineering language patterns in email body"))

    if keywords:
        sample = ", ".join(f'"{k}"' for k in keywords[:5])
        results.append((0.40, f"Suspicious keywords found: {sample}"))

    if not b.get("plain_text") and b.get("html_present"):
        results.append((0.35, "Email has no plain-text body — HTML-only layout commonly used to hide content"))

    return results


def _url_indicators(u: Dict[str, Any]) -> List[Tuple[float, str]]:
    results = []

    if u.get("ip_based_urls"):
        sample = u["ip_based_urls"][0]
        results.append((0.90, f"IP-address-based URL detected ({sample[:60]}) — bypasses domain reputation checks"))

    if u.get("shortener_urls"):
        sample = u["shortener_urls"][0]
        results.append((0.75, f"URL shortener detected ({sample[:60]}) — masks true destination of link"))

    if u.get("punycode_domains"):
        sample = u["punycode_domains"][0]
        results.append((0.85, f"Punycode/IDN domain detected ({sample[:60]}) — homograph attack disguising lookalike chars"))

    if u.get("brand_impersonation_urls"):
        sample = u["brand_impersonation_urls"][0]
        results.append((0.90, f"Brand impersonation in URL detected ({sample[:60]})"))

    if u.get("anchor_mismatch_urls"):
        results.append((0.80, "Hyperlink text shows a trusted domain but href redirects to a different domain"))

    if u.get("suspicious_tlds"):
        tlds = list(set(
            "." + url.split(".")[-1].split("/")[0]
            for url in u.get("suspicious_tlds", [])
        ))
        results.append((0.65, f"Suspicious TLD(s) in URLs: {', '.join(tlds[:4])}"))

    if u.get("http_only_urls"):
        count = len(u["http_only_urls"])
        results.append((0.50, f"{count} URL(s) use plain HTTP — no encryption, susceptible to interception"))

    if u.get("excessive_subdomain_urls"):
        results.append((0.60, "URLs with excessive subdomains detected — used to obscure true domain"))

    total = u.get("total_urls", 0)
    phish_count = u.get("phishing_url_count", 0)
    if total > 0 and phish_count > 0:
        ratio = phish_count / total
        if ratio > 0.5:
            results.append((0.70, f"{phish_count} of {total} URLs contain phishing indicators ({int(ratio*100)}% suspicious)"))

    return results


def _attachment_indicators(a: Dict[str, Any]) -> List[Tuple[float, str]]:
    results = []

    if a.get("executable_count", 0) > 0:
        results.append((0.95, f"{a['executable_count']} executable attachment(s) detected — high malware risk"))

    if a.get("macro_enabled_count", 0) > 0:
        results.append((0.90, f"{a['macro_enabled_count']} macro-enabled Office document(s) detected — may execute malicious code"))

    if a.get("archive_count", 0) > 0:
        results.append((0.70, f"{a['archive_count']} archive attachment(s) detected — often used to conceal payloads"))

    if a.get("dangerous_extension_count", 0) > 0 and a.get("executable_count", 0) == 0:
        results.append((0.60, f"{a['dangerous_extension_count']} attachment(s) with potentially dangerous file extensions"))

    return results


def generate_indicators(features: Dict[str, Any]) -> List[str]:
    """
    Generate a ranked list of human-readable phishing indicator strings.
    Sorted by severity weight (highest first), top 10 returned.
    """
    h = features.get("headers", {})
    b = features.get("body", {})
    u = features.get("urls", {})
    a = features.get("attachments", {})
    s = features.get("sender", {})

    all_indicators: List[Tuple[float, str]] = []
    all_indicators.extend(_header_indicators(h, s))
    all_indicators.extend(_body_indicators(b))
    all_indicators.extend(_url_indicators(u))
    all_indicators.extend(_attachment_indicators(a))

    # Sort by weight descending, deduplicate messages
    seen_msgs: set = set()
    ranked: List[str] = []
    for weight, msg in sorted(all_indicators, key=lambda x: x[0], reverse=True):
        if msg not in seen_msgs:
            seen_msgs.add(msg)
            ranked.append(msg)
        if len(ranked) >= 10:
            break

    if not ranked:
        ranked.append("No significant phishing indicators detected")

    return ranked


def compute_rule_based_score(features: Dict[str, Any]) -> float:
    """
    Compute a rule-based risk score (0.0–1.0) as a supplementary signal.
    Used alongside ML score for final weighting.
    """
    h = features.get("headers", {})
    b = features.get("body", {})
    u = features.get("urls", {})
    a = features.get("attachments", {})
    s = features.get("sender", {})

    score = 0.0
    max_score = 0.0

    def add(weight: float, condition: bool) -> None:
        nonlocal score, max_score
        max_score += weight
        if condition:
            score += weight

    # Header signals
    add(0.10, h.get("from_reply_to_mismatch", False))
    add(0.08, h.get("return_path_mismatch", False))
    add(0.12, h.get("display_name_spoofing", False))
    add(0.06, h.get("suspicious_relay", False))
    add(0.10, (h.get("spf_result") or "").lower() in ("fail", "softfail"))
    add(0.10, (h.get("dkim_result") or "").lower() == "fail")
    add(0.10, (h.get("dmarc_result") or "").lower() == "fail")
    add(0.12, s.get("typosquatting_score", 0) > 0.7)
    add(0.04, s.get("free_email_provider", False))

    # Body signals
    add(0.08, b.get("urgency_score", 0) > 0.3)
    add(0.10, b.get("credential_bait_score", 0) > 0.3)
    add(0.08, b.get("financial_bait_score", 0) > 0.3)
    add(0.06, b.get("social_engineering_score", 0) > 0.3)
    add(0.04, len(b.get("suspicious_keywords", [])) > 5)

    # URL signals
    add(0.15, len(u.get("ip_based_urls", [])) > 0)
    add(0.10, len(u.get("shortener_urls", [])) > 0)
    add(0.12, len(u.get("punycode_domains", [])) > 0)
    add(0.12, len(u.get("brand_impersonation_urls", [])) > 0)
    add(0.10, len(u.get("anchor_mismatch_urls", [])) > 0)
    add(0.06, len(u.get("suspicious_tlds", [])) > 0)
    add(0.08, len(u.get("http_only_urls", [])) > 2)

    # Attachment signals
    add(0.20, a.get("executable_count", 0) > 0)
    add(0.18, a.get("macro_enabled_count", 0) > 0)
    add(0.10, a.get("archive_count", 0) > 0)

    if max_score == 0:
        return 0.0
    return round(min(score / max_score, 1.0), 4)
