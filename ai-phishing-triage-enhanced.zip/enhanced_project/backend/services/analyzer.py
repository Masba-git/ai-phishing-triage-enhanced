"""
Analysis orchestrator.

Entry point for the full phishing analysis pipeline:
  parse email → extract features → ML inference → explainability → triage
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any, Dict, Optional


from backend.services.email_parser import parse_email
from backend.services.feature_extractor import extract_all_features, build_numeric_feature_vector
from backend.services.explainability import generate_indicators, compute_rule_based_score
from backend.services.inference import get_engine
from backend.services.triage import score_to_verdict, score_to_triage_status, save_triage_record
from backend.services.attack_type_classifier import get_classifier
from backend.models.schemas import (
    AnalysisResult, HeaderFeatures, BodyFeatures,
    URLFeatures, AttachmentFeatures, SenderFeatures,
)
from utils.logger import logger


def analyze_email(
    raw_email: str,
    filename: Optional[str] = None,
    analyst_note: Optional[str] = None,
) -> AnalysisResult:
    """
    Run the full phishing analysis pipeline on a raw email string.

    Steps:
    1. Parse email (headers, body, URLs, attachments)
    2. Extract structured + numeric features
    3. Rule-based risk score
    4. ML inference (blended risk score)
    5. Generate analyst explanations
    6. Assign verdict + triage status
    7. Persist triage record
    8. Return structured AnalysisResult
    """
    analysis_id = str(uuid.uuid4())
    timestamp = datetime.now(timezone.utc).isoformat()

    logger.info(f"Starting analysis [{analysis_id}] file={filename or 'pasted'}")

    # ------------------------------------------------------------------
    # 1. Parse
    # ------------------------------------------------------------------
    parsed = parse_email(raw_email)

    # ------------------------------------------------------------------
    # 2. Feature extraction
    # ------------------------------------------------------------------
    features = extract_all_features(parsed)
    numeric_vec = build_numeric_feature_vector(features)

    # ------------------------------------------------------------------
    # 3. Rule-based score
    # ------------------------------------------------------------------
    rule_score = compute_rule_based_score(features)

    # ------------------------------------------------------------------
    # 4. ML inference
    # ------------------------------------------------------------------
    engine = get_engine()
    risk_score, confidence, feature_importance = engine.predict(numeric_vec, rule_score)

    # ------------------------------------------------------------------
    # 5. Explainability
    # ------------------------------------------------------------------
    indicators = generate_indicators(features)

    # ------------------------------------------------------------------
    # 5.5 Attack Type Classification (NEW FEATURE)
    # ------------------------------------------------------------------
    classifier = get_classifier()
    attack_type_results = classifier.classify(
        features=features,
        parsed_email={
            'body_text': parsed.body_text or '',
            'body_html': parsed.body_html or '',
            'subject': parsed.subject or ''
        }
    )
    attack_types_formatted = classifier.format_result_for_display(attack_type_results)
    detected_attacks = classifier.get_detected_attacks(attack_type_results)

    # ------------------------------------------------------------------
    # 6. Verdict + triage
    # ------------------------------------------------------------------
    verdict = score_to_verdict(risk_score)
    triage_status = score_to_triage_status(risk_score)
    risk_percent = int(round(risk_score * 100))

    logger.info(
        f"Analysis [{analysis_id}] complete — score={risk_score:.3f} "
        f"verdict={verdict} triage={triage_status}"
    )

    # ------------------------------------------------------------------
    # 7. Persist triage record
    # ------------------------------------------------------------------
    save_triage_record(
        analysis_id=analysis_id,
        subject=parsed.subject,
        sender=parsed.from_address,
        verdict=verdict,
        risk_score=risk_score,
        triage_status=triage_status,
        analyst_note=analyst_note,
    )

    # ------------------------------------------------------------------
    # 8. Build response
    # ------------------------------------------------------------------
    h = features["headers"]
    b = features["body"]
    u = features["urls"]
    a = features["attachments"]
    s = features["sender"]

    return AnalysisResult(
        analysis_id=analysis_id,
        timestamp=timestamp,
        filename=filename,
        headers=HeaderFeatures(
            from_address=h.get("from_address"),
            reply_to=h.get("reply_to"),
            return_path=h.get("return_path"),
            subject=h.get("subject"),
            date=h.get("date"),
            message_id=h.get("message_id"),
            mailer=h.get("mailer"),
            spf_result=h.get("spf_result"),
            dkim_result=h.get("dkim_result"),
            dmarc_result=h.get("dmarc_result"),
            from_reply_to_mismatch=h.get("from_reply_to_mismatch", False),
            return_path_mismatch=h.get("return_path_mismatch", False),
            display_name_spoofing=h.get("display_name_spoofing", False),
            suspicious_relay=h.get("suspicious_relay", False),
        ),
        body=BodyFeatures(
            plain_text=b.get("plain_text"),
            html_present=b.get("html_present", False),
            char_count=b.get("char_count", 0),
            word_count=b.get("word_count", 0),
            urgency_score=b.get("urgency_score", 0.0),
            credential_bait_score=b.get("credential_bait_score", 0.0),
            financial_bait_score=b.get("financial_bait_score", 0.0),
            social_engineering_score=b.get("social_engineering_score", 0.0),
            suspicious_keywords=b.get("suspicious_keywords", []),
        ),
        urls=URLFeatures(
            urls_found=u.get("urls_found", []),
            ip_based_urls=u.get("ip_based_urls", []),
            shortener_urls=u.get("shortener_urls", []),
            suspicious_tlds=u.get("suspicious_tlds", []),
            punycode_domains=u.get("punycode_domains", []),
            http_only_urls=u.get("http_only_urls", []),
            excessive_subdomain_urls=u.get("excessive_subdomain_urls", []),
            anchor_mismatch_urls=u.get("anchor_mismatch_urls", []),
            brand_impersonation_urls=u.get("brand_impersonation_urls", []),
            total_urls=u.get("total_urls", 0),
            phishing_url_count=u.get("phishing_url_count", 0),
        ),
        attachments=AttachmentFeatures(
            attachments=a.get("attachments", []),
            dangerous_extension_count=a.get("dangerous_extension_count", 0),
            macro_enabled_count=a.get("macro_enabled_count", 0),
            archive_count=a.get("archive_count", 0),
            executable_count=a.get("executable_count", 0),
            has_dangerous_attachment=a.get("has_dangerous_attachment", False),
        ),
        sender=SenderFeatures(
            sender_domain=s.get("sender_domain"),
            domain_age_heuristic=s.get("domain_age_heuristic", "unknown"),
            typosquatting_score=s.get("typosquatting_score", 0.0),
            domain_similarity_targets=s.get("domain_similarity_targets", []),
            free_email_provider=s.get("free_email_provider", False),
            domain_mismatch_score=s.get("domain_mismatch_score", 0.0),
        ),
        risk_score=risk_score,
        risk_percent=risk_percent,
        verdict=verdict,
        confidence=confidence,
        top_indicators=indicators,
        ml_feature_importance=feature_importance,
        triage_status=triage_status,
        analyst_note=analyst_note,
        # NEW FIELDS: Attack Type Classification
        attack_type_results=attack_types_formatted,
        detected_attacks=detected_attacks,
    )
